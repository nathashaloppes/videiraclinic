import { RouterProvider } from 'react-router';
import { router } from './routes';
import { AuthProvider } from './contexts/AuthContext';
import { ReservasProvider } from './contexts/ReservasContext';
import { AdminProvider } from './contexts/AdminContext';
import { Toaster } from 'sonner';

export default function App() {
  return (
    <AuthProvider>
      <ReservasProvider>
        <AdminProvider>
          <RouterProvider router={router} />
          <Toaster richColors position="top-center" />
        </AdminProvider>
      </ReservasProvider>
    </AuthProvider>
  );
}