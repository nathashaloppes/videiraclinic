import { User } from 'lucide-react';

interface AvatarProps {
  user?: {
    nomeCompleto: string;
    fotoPerfil?: string;
  } | null;
  size?: 'sm' | 'md' | 'lg';
}

export function Avatar({ user, size = 'md' }: AvatarProps) {
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-24 h-24 text-3xl',
  };

  const getInitials = (nome: string) => {
    const parts = nome.trim().split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }
    return nome.substring(0, 2).toUpperCase();
  };

  if (!user) {
    return (
      <div
        className={`${sizeClasses[size]} rounded-full bg-gray-300 flex items-center justify-center`}
      >
        <User className="w-5 h-5 text-gray-600" />
      </div>
    );
  }

  if (user.fotoPerfil) {
    return (
      <img
        src={user.fotoPerfil}
        alt={user.nomeCompleto}
        className={`${sizeClasses[size]} rounded-full object-cover`}
      />
    );
  }

  return (
    <div
      className={`${sizeClasses[size]} rounded-full flex items-center justify-center text-white`}
      style={{ backgroundColor: '#8D6E63' }}
    >
      {getInitials(user.nomeCompleto)}
    </div>
  );
}
