import { useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CalendarioAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: Date;
  onSelectDate: (date: Date) => void;
}

export function CalendarioAdminModal({
  isOpen,
  onClose,
  selectedDate,
  onSelectDate,
}: CalendarioAdminModalProps) {
  const [currentMonth, setCurrentMonth] = useState(selectedDate.getMonth());
  const [currentYear, setCurrentYear] = useState(selectedDate.getFullYear());

  const today = new Date();
  const minDate = new Date();
  minDate.setFullYear(minDate.getFullYear() - 1); // 1 ano atrás
  const maxDate = new Date();
  maxDate.setMonth(maxDate.getMonth() + 3); // 3 meses à frente

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const dayNames = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'];

  const canGoBack = () => {
    const prevMonth = new Date(currentYear, currentMonth - 1);
    return prevMonth >= new Date(minDate.getFullYear(), minDate.getMonth());
  };

  const canGoForward = () => {
    const nextMonth = new Date(currentYear, currentMonth + 1);
    return nextMonth <= maxDate;
  };

  const handlePrevMonth = () => {
    if (canGoBack()) {
      if (currentMonth === 0) {
        setCurrentMonth(11);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
    }
  };

  const handleNextMonth = () => {
    if (canGoForward()) {
      if (currentMonth === 11) {
        setCurrentMonth(0);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
    }
  };

  const handleDateClick = (day: number) => {
    const newDate = new Date(currentYear, currentMonth, day);
    if (newDate >= minDate && newDate <= maxDate) {
      onSelectDate(newDate);
      onClose();
    }
  };

  const isDateDisabled = (day: number) => {
    const date = new Date(currentYear, currentMonth, day);
    return date < minDate || date > maxDate;
  };

  const isDateSelected = (day: number) => {
    return (
      day === selectedDate.getDate() &&
      currentMonth === selectedDate.getMonth() &&
      currentYear === selectedDate.getFullYear()
    );
  };

  const days = [];
  for (let i = 0; i < firstDayOfMonth; i++) {
    days.push(<div key={`empty-${i}`} />);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    days.push(day);
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/30 z-40"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white rounded-3xl p-6 shadow-2xl w-[90vw] max-w-md overflow-x-hidden"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100"
            >
              <X className="w-5 h-5" style={{ color: '#8D6E63' }} />
            </button>

            <div className="flex items-center justify-center gap-3 mb-6">
              <button
                onClick={handlePrevMonth}
                disabled={!canGoBack()}
                className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30 disabled:hover:bg-transparent"
              >
                <ChevronLeft className="w-5 h-5" style={{ color: '#5D4037' }} />
              </button>

              <div className="text-lg" style={{ color: '#5D4037' }}>
                {monthNames[currentMonth]} de {currentYear}
              </div>

              <button
                onClick={handleNextMonth}
                disabled={!canGoForward()}
                className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30 disabled:hover:bg-transparent"
              >
                <ChevronRight className="w-5 h-5" style={{ color: '#5D4037' }} />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-2 mb-2">
              {dayNames.map(day => (
                <div
                  key={day}
                  className="text-center text-xs py-2"
                  style={{ color: '#8D6E63' }}
                >
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-2">
              {days.map((day, index) => {
                if (typeof day !== 'number') {
                  return <div key={`day-${index}`} />;
                }

                const disabled = isDateDisabled(day);
                const selected = isDateSelected(day);

                return (
                  <button
                    key={day}
                    onClick={() => handleDateClick(day)}
                    disabled={disabled}
                    className={`
                      aspect-square rounded-full flex items-center justify-center text-sm
                      ${disabled ? 'opacity-30 cursor-not-allowed' : 'hover:bg-gray-100'}
                      ${selected ? 'text-white' : ''}
                    `}
                    style={
                      selected
                        ? { backgroundColor: '#5D4037' }
                        : { color: '#3E2723' }
                    }
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
