import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { X, ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { format, addDays, differenceInDays, addMonths, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { CalendarioModal } from './CalendarioModal';
import { useReservas, type Reserva, type Turno } from '../contexts/ReservasContext';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { db } from '../services/database';

interface EditarReservaClienteModalProps {
  reserva: Reserva;
  onClose: () => void;
}

export function EditarReservaClienteModal({ reserva, onClose }: EditarReservaClienteModalProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { turnosDisponiveis } = useReservas();

  const [selectedDate, setSelectedDate] = useState(reserva.data);
  const [selectedTurno, setSelectedTurno] = useState<Turno | null>(null);
  const [weekDates, setWeekDates] = useState<Date[]>([]);
  const [weekStartIndex, setWeekStartIndex] = useState(0);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [mostrarConfirmacaoCancelar, setMostrarConfirmacaoCancelar] = useState(false);

  useEffect(() => {
    const today = startOfDay(new Date());
    const tomorrow = addDays(today, 1);
    const maxDate = addMonths(tomorrow, 3);
    const totalDays = differenceInDays(maxDate, tomorrow) + 1;
    const dates = Array.from({ length: totalDays }, (_, i) => addDays(tomorrow, i));
    setWeekDates(dates);
    setWeekStartIndex(0);
  }, []);

  const visibleDates = weekDates.slice(weekStartIndex, weekStartIndex + 7);
  const availableTurnos = turnosDisponiveis(selectedDate);

  const updateWeekForDate = (date: Date) => {
    if (weekDates.length === 0) return;
    const today = startOfDay(new Date());
    const daysSinceToday = differenceInDays(date, today);
    const newWeekIndex = Math.max(0, Math.floor(daysSinceToday / 7) * 7);
    if (newWeekIndex < weekDates.length) {
      setWeekStartIndex(newWeekIndex);
    }
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setSelectedTurno(null); // Limpar turno selecionado ao mudar a data
    updateWeekForDate(date);
    setIsCalendarOpen(false);
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setSelectedTurno(null); // Limpar turno selecionado ao mudar a data
  };

  const handleNextWeek = () => {
    if (weekStartIndex + 7 < weekDates.length) {
      setWeekStartIndex(weekStartIndex + 7);
    }
  };

  const handlePrevWeek = () => {
    if (weekStartIndex - 7 >= 0) {
      setWeekStartIndex(weekStartIndex - 7);
    }
  };

  const handleConfirmar = () => {
    if (!selectedTurno || !user) {
      toast.error('Selecione um novo turno');
      return;
    }

    const diferencaValor = selectedTurno.preco - reserva.total;

    if (diferencaValor > 0) {
      // Precisa pagar a diferença - ir para tela de pagamento
      onClose();
      navigate('/pagamento', {
        state: {
          valorDiferenca: diferencaValor,
          reservaId: reserva.id,
          novaData: selectedDate,
          novoTurno: selectedTurno
        }
      });
    } else if (diferencaValor < 0) {
      // Gera crédito
      const credito = Math.abs(diferencaValor);
      db.adicionarCredito(
        user.id,
        credito,
        'Crédito gerado por alteração de reserva',
        reserva.id
      );

      // Atualizar a reserva
      atualizarReserva();
      toast.success(`Reserva alterada! Você ganhou R$ ${(credito / 100).toFixed(2).replace('.', ',')} em créditos!`);
      window.dispatchEvent(new Event('creditoAtualizado'));
      onClose();
    } else {
      // Mesmo valor
      atualizarReserva();
      toast.success('Reserva alterada com sucesso!');
      onClose();
    }
  };

  const atualizarReserva = () => {
    if (!selectedTurno) return;

    // Liberar turnos antigos (passando o ID da reserva para excluir da verificação)
    const dataAntigaFormatada = format(reserva.data, 'yyyy-MM-dd');
    db.liberarTurnos(
      dataAntigaFormatada,
      reserva.turnos[0].horario.split(' às ')[0].replace('h', ':'),
      reserva.turnos[0].horario.split(' às ')[1].replace('h', ':'),
      reserva.id // Excluir esta reserva da verificação
    );

    // Calcular novos horários
    const novoInicio = selectedTurno.horario.split(' às ')[0].replace('h', ':');
    const novoFim = selectedTurno.horario.split(' às ')[1].replace('h', ':');
    const novaData = format(selectedDate, 'yyyy-MM-dd');

    // Atualizar reserva no banco de dados
    db.updateReserva(reserva.id, {
      data: novaData,
      inicio: novoInicio,
      fim: novoFim,
      periodo: selectedTurno.nome,
      valor: selectedTurno.preco,
    });

    // Marcar novos turnos como reservados
    db.marcarTurnosComoReservados(novaData, novoInicio, novoFim);

    // Emitir evento para sincronização
    window.dispatchEvent(new CustomEvent('reservaAtualizada', {
      detail: { reservaId: reserva.id }
    }));
  };

  const handleCancelarReserva = () => {
    if (!user) return;

    // Liberar turnos
    const dataFormatada = format(reserva.data, 'yyyy-MM-dd');
    db.liberarTurnos(dataFormatada, reserva.turnos[0].horario.split(' às ')[0].replace('h', ':'), reserva.turnos[0].horario.split(' às ')[1].replace('h', ':'));

    // Estornar valor como crédito
    db.adicionarCredito(
      user.id,
      reserva.total,
      'Estorno de cancelamento de reserva',
      reserva.id
    );

    // Marcar reserva como cancelada no banco de dados
    db.updateReserva(reserva.id, { status: 'cancelada' });

    // Disparar evento para sincronizar com AdminContext e ReservasContext
    window.dispatchEvent(new CustomEvent('reservaCancelada', {
      detail: { reservaId: reserva.id }
    }));

    toast.success(`Reserva cancelada! R$ ${(reserva.total / 100).toFixed(2).replace('.', ',')} adicionados aos seus créditos.`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 30 }}
        className="bg-white rounded-t-3xl w-full max-w-md max-h-[90vh] overflow-y-auto"
        style={{ backgroundColor: '#fef8e1' }}
      >
        <div className="sticky top-0 bg-white rounded-t-3xl p-6 shadow-sm z-10" style={{ backgroundColor: '#fef8e1' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl" style={{ color: '#5D4037' }}>
              Alterar Reserva
            </h2>
            <button onClick={onClose} className="p-2 hover:bg-white/50 rounded-full">
              <X className="w-6 h-6" style={{ color: '#5D4037' }} />
            </button>
          </div>

          {/* Reserva Atual */}
          <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
            <p className="text-sm mb-2" style={{ color: '#8D6E63' }}>Reserva atual:</p>
            <p className="text-sm" style={{ color: '#3E2723' }}>
              {format(reserva.data, "dd 'de' MMMM", { locale: ptBR })} • {reserva.turnos[0].horario}
            </p>
            <p className="text-sm" style={{ color: '#5D4037' }}>
              R$ {(reserva.total / 100).toFixed(2).replace('.', ',')}
            </p>
          </div>

          {/* Nova Reserva (se turno selecionado) */}
          {selectedTurno && (
            <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm border-2" style={{ borderColor: '#5D4037' }}>
              <p className="text-sm mb-2" style={{ color: '#8D6E63' }}>Nova reserva:</p>
              <p className="text-sm" style={{ color: '#3E2723' }}>
                {format(selectedDate, "dd 'de' MMMM", { locale: ptBR })} • {selectedTurno.horario}
              </p>
              <p className="text-sm" style={{ color: '#5D4037' }}>
                R$ {(selectedTurno.preco / 100).toFixed(2).replace('.', ',')}
              </p>
            </div>
          )}
        </div>

        <div className="px-6 pb-6">
          <p className="text-sm mb-4" style={{ color: '#8D6E63' }}>
            Selecione uma nova data e turno:
          </p>

          {/* Botão Calendário */}
          <button
            onClick={() => setIsCalendarOpen(true)}
            className="flex items-center gap-2 px-4 py-3 rounded-full mb-4 w-full justify-center bg-white shadow-sm"
            style={{ color: '#5D4037' }}
          >
            <CalendarIcon className="w-4 h-4" />
            <span className="text-sm">
              {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </span>
          </button>

          {/* Rolagem de datas */}
          <div className="mb-6">
            <div className="flex items-center gap-3">
              <button
                onClick={handlePrevWeek}
                disabled={weekStartIndex === 0}
                className="p-2 rounded-full disabled:opacity-30 bg-white"
              >
                <ChevronLeft className="w-5 h-5" style={{ color: '#5D4037' }} />
              </button>

              <div className="flex-1 grid grid-cols-7 gap-2">
                {visibleDates.map((date, index) => {
                  const isSelected = date.toDateString() === selectedDate.toDateString();
                  return (
                    <button
                      key={index}
                      onClick={() => handleDateClick(date)}
                      className="flex flex-col items-center py-2 px-1 rounded-2xl transition-all"
                      style={{
                        backgroundColor: isSelected ? '#5D4037' : '#FFF',
                        color: isSelected ? 'white' : '#3E2723',
                      }}
                    >
                      <span className="text-xs font-medium">
                        {format(date, 'EEEEEE', { locale: ptBR }).toUpperCase()}
                      </span>
                      <span className="text-lg font-semibold">
                        {format(date, 'd')}
                      </span>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={handleNextWeek}
                disabled={weekStartIndex + 7 >= weekDates.length}
                className="p-2 rounded-full disabled:opacity-30 bg-white"
              >
                <ChevronRight className="w-5 h-5" style={{ color: '#5D4037' }} />
              </button>
            </div>
          </div>

          {/* Turnos Disponíveis */}
          <div className="space-y-3 mb-6">
            {availableTurnos.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 text-center">
                <p style={{ color: '#8D6E63' }}>Nenhum turno disponível nesta data</p>
              </div>
            ) : (
              availableTurnos.map((turno) => {
                const isSelected = selectedTurno?.id === turno.id;
                return (
                  <button
                    key={turno.id}
                    onClick={() => setSelectedTurno(turno)}
                    className="w-full bg-white rounded-2xl p-4 text-left transition-all shadow-sm"
                    style={{
                      borderWidth: isSelected ? 2 : 0,
                      borderColor: isSelected ? '#5D4037' : 'transparent',
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p style={{ color: '#3E2723' }}>{turno.nome}</p>
                        <p className="text-xs" style={{ color: '#8D6E63' }}>
                          {turno.horario}
                        </p>
                      </div>
                      <p style={{ color: '#5D4037' }}>
                        R$ {(turno.preco / 100).toFixed(2).replace('.', ',')}
                      </p>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Informação de diferença de valor */}
          {selectedTurno && (
            <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
              {selectedTurno.preco > reserva.total ? (
                <p className="text-sm" style={{ color: '#D32F2F' }}>
                  Você precisará pagar R$ {((selectedTurno.preco - reserva.total) / 100).toFixed(2).replace('.', ',')} de diferença
                </p>
              ) : selectedTurno.preco < reserva.total ? (
                <p className="text-sm" style={{ color: '#388E3C' }}>
                  Você receberá R$ {((reserva.total - selectedTurno.preco) / 100).toFixed(2).replace('.', ',')} em créditos
                </p>
              ) : (
                <p className="text-sm" style={{ color: '#8D6E63' }}>
                  Mesmo valor da reserva atual
                </p>
              )}
            </div>
          )}

          {/* Botão Confirmar */}
          <button
            onClick={handleConfirmar}
            disabled={!selectedTurno}
            className="w-full py-3 rounded-full text-white disabled:opacity-50 mb-3"
            style={{ backgroundColor: '#5D4037' }}
          >
            Confirmar Alteração
          </button>

          {/* Botão Cancelar Reserva */}
          <button
            onClick={() => setMostrarConfirmacaoCancelar(true)}
            className="w-full py-3 rounded-full border-2 text-sm"
            style={{ borderColor: '#D32F2F', color: '#D32F2F' }}
          >
            Cancelar Reserva
          </button>
        </div>

        <CalendarioModal
          isOpen={isCalendarOpen}
          onClose={() => setIsCalendarOpen(false)}
          onSelectDate={handleDateSelect}
          selectedDate={selectedDate}
        />

        {/* Modal de Confirmação de Cancelamento */}
        {mostrarConfirmacaoCancelar && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60]">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-3xl p-8 max-w-sm mx-4 shadow-xl"
            >
              <h3 className="text-lg mb-4 text-center" style={{ color: '#5D4037' }}>
                Cancelar Reserva?
              </h3>
              <p className="text-sm mb-6 text-center" style={{ color: '#8D6E63' }}>
                O valor de R$ {(reserva.total / 100).toFixed(2).replace('.', ',')} será estornado como crédito em sua carteira.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setMostrarConfirmacaoCancelar(false)}
                  className="flex-1 py-3 rounded-full border-2"
                  style={{ borderColor: '#5D4037', color: '#5D4037' }}
                >
                  Não
                </button>
                <button
                  onClick={handleCancelarReserva}
                  className="flex-1 py-3 rounded-full text-white"
                  style={{ backgroundColor: '#D32F2F' }}
                >
                  Sim, cancelar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
