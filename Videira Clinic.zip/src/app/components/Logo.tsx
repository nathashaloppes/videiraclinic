import logoImage from "figma:asset/ab11688c7017938db3077d2606caa695dafd98c5.png";

export function Logo({ className = '' }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center w-full ${className}`}>
      <img 
        src={logoImage} 
        alt="Videira Clinic Logo" 
        className="w-48 h-auto"
      />
    </div>
  );
}