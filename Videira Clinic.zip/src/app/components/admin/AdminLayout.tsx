import { ReactNode, useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { Calendar, Users, Settings, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Logo } from '../Logo';
import { useAuth } from '../../contexts/AuthContext';

interface AdminLayoutProps {
  children: ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  useEffect(() => {
    if (!user?.isAdmin) {
      navigate('/login');
    }
  }, [user, navigate]);

  if (!user?.isAdmin) {
    return null;
  }

  const menuItems = [
    { icon: Calendar, label: 'Reservas', path: '/admin/reservas' },
    { icon: Users, label: 'Clientes', path: '/admin/clientes' },
    { icon: Settings, label: 'Turnos', path: '/admin/configurar' },
    { icon: LogOut, label: 'Sair', path: '/logout' },
  ];

  const handleNavigation = (path: string) => {
    if (path === '/logout') {
      setShowLogoutModal(true);
    } else {
      navigate(path);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <>
      <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
        <div className="max-w-md mx-auto px-4 py-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center mb-8"
          >
            <Logo />
          </motion.div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;

              return (
                <button
                  key={item.path}
                  onClick={() => handleNavigation(item.path)}
                  className="flex items-center justify-center gap-2 px-6 py-3 rounded-full text-sm transition-all"
                  style={{
                    backgroundColor: isActive ? '#8D6E63' : '#E0E0E0',
                    color: isActive ? 'white' : '#5D4037',
                  }}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </button>
              );
            })}
          </div>

          {children}
        </div>
      </div>

      <AnimatePresence>
        {showLogoutModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/30 z-40"
              onClick={() => setShowLogoutModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white rounded-3xl p-8 shadow-2xl w-[90vw] max-w-sm"
            >
              <h3 className="text-lg mb-6 text-center" style={{ color: '#5D4037' }}>
                Tem certeza que deseja sair?
              </h3>

              <div className="flex gap-4">
                <button
                  onClick={() => setShowLogoutModal(false)}
                  className="flex-1 py-3 rounded-full border-2"
                  style={{ borderColor: '#5D4037', color: '#5D4037' }}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleLogout}
                  className="flex-1 py-3 rounded-full text-white"
                  style={{ backgroundColor: '#5D4037' }}
                >
                  Sair
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}