import { useState } from 'react';
import { X, Camera } from 'lucide-react';
import { motion } from 'motion/react';

interface AdicionarClienteModalProps {
  onClose: () => void;
  onSave: (cliente: {
    nomeCompleto: string;
    email: string;
    telefone: string;
    registroCRO: string;
    areaAtuacao: string;
    dataNascimento: string;
    endereco: string;
    fotoPerfil?: string;
  }) => void;
}

export function AdicionarClienteModal({ onClose, onSave }: AdicionarClienteModalProps) {
  const [nomeCompleto, setNomeCompleto] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [telefone, setTelefone] = useState('');
  const [email, setEmail] = useState('');
  const [registroCRO, setRegistroCRO] = useState('');
  const [areaAtuacao, setAreaAtuacao] = useState('');
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [cep, setCep] = useState('');
  const [fotoPerfil, setFotoPerfil] = useState<string>();

  const formatTelefone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return numbers.replace(/(\d{2})(\d+)/, '($1)$2');
    if (numbers.length <= 11) return numbers.replace(/(\d{2})(\d{5})(\d+)/, '($1)$2-$3');
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1)$2-$3');
  };

  const formatDataNascimento = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 4) return numbers.replace(/(\d{2})(\d+)/, '$1/$2');
    return numbers.replace(/(\d{2})(\d{2})(\d+)/, '$1/$2/$3').substring(0, 10);
  };

  const formatCep = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 5) return numbers;
    return numbers.replace(/(\d{5})(\d+)/, '$1-$2').substring(0, 9);
  };

  const handleCEPChange = async (value: string) => {
    const formatted = formatCep(value);
    setCep(formatted);

    // Se CEP estiver completo, buscar endereço
    const numbers = formatted.replace(/\D/g, '');
    if (numbers.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${numbers}/json/`);
        const data = await response.json();
        
        if (!data.erro) {
          setRua(data.logradouro || '');
          setBairro(data.bairro || '');
          setCidade(data.localidade || '');
          setEstado(data.uf || '');
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  const handleSalvar = () => {
    if (!nomeCompleto || !email || !telefone || !registroCRO || !areaAtuacao) return;

    const enderecoCompleto = [
      rua && numero ? `${rua}, ${numero}` : rua || numero,
      complemento,
      bairro,
      cidade && estado ? `${cidade} - ${estado}` : cidade || estado,
      cep
    ].filter(Boolean).join(', ');

    onSave({
      nomeCompleto,
      email,
      telefone,
      registroCRO,
      areaAtuacao,
      dataNascimento,
      endereco: enderecoCompleto,
      fotoPerfil,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg flex items-center gap-2" style={{ color: '#5D4037' }}>
            <span className="text-2xl">+</span> Adicionar cliente
          </h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" style={{ color: '#5D4037' }} />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col items-center mb-4">
            <div className="relative">
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#E0E0E0' }}
              >
                {fotoPerfil ? (
                  <img src={fotoPerfil} alt="Perfil" className="w-full h-full rounded-full object-cover" />
                ) : (
                  <div className="text-2xl" style={{ color: '#8D6E63' }}>
                    {nomeCompleto
                      ? nomeCompleto
                          .split(' ')
                          .map((n) => n[0])
                          .join('')
                          .toUpperCase()
                          .slice(0, 2)
                      : ''}
                  </div>
                )}
              </div>
              <button
                type="button"
                className="absolute bottom-0 right-0 w-6 h-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#5D4037' }}
              >
                <Camera className="w-3 h-3 text-white" />
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Nome completo
            </label>
            <input
              type="text"
              placeholder="Digite o nome completo"
              value={nomeCompleto}
              onChange={(e) => setNomeCompleto(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            />
          </div>

           <div>
              <input
                type="text"
                placeholder="Registro CRO*"
                value={registroCRO}
                onChange={(e) => setRegistroCRO(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="text"
                placeholder="Área de atuação*"
                value={areaAtuacao}
                onChange={(e) => setAreaAtuacao(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                Data de nascimento
              </label>
              <input
                type="text"
                placeholder="dd/mm/aaaa"
                value={dataNascimento}
                onChange={(e) => setDataNascimento(formatDataNascimento(e.target.value))}
                autoComplete="bday"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                Contato
              </label>
              <input
                type="tel"
                placeholder="(00)00000-0000"
                value={telefone}
                onChange={(e) => setTelefone(formatTelefone(e.target.value))}
                autoComplete="tel"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              E-mail
            </label>
            <input
              type="email"
              placeholder="Digite o e-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            />
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Endereço completo
            </label>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Rua"
                value={rua}
                onChange={(e) => setRua(e.target.value)}
                autoComplete="address-line1"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
              
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Número"
                  value={numero}
                  onChange={(e) => setNumero(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
                <input
                  type="text"
                  placeholder="Complemento"
                  value={complemento}
                  onChange={(e) => setComplemento(e.target.value)}
                  autoComplete="address-line2"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <input
                type="text"
                placeholder="Bairro"
                value={bairro}
                onChange={(e) => setBairro(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />

              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Cidade"
                  value={cidade}
                  onChange={(e) => setCidade(e.target.value)}
                  autoComplete="address-level2"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
                <input
                  type="text"
                  placeholder="Estado"
                  value={estado}
                  onChange={(e) => setEstado(e.target.value)}
                  autoComplete="address-level1"
                  maxLength={2}
                  className="w-full px-4 py-3 rounded-2xl border text-sm uppercase"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <input
                type="text"
                placeholder="CEP"
                value={cep}
                onChange={(e) => handleCEPChange(e.target.value)}
                autoComplete="postal-code"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>
          </div>

          <button
            onClick={handleSalvar}
            disabled={!nomeCompleto || !email || !telefone || !registroCRO || !areaAtuacao}
            className="w-full py-3 rounded-full text-white disabled:opacity-50"
            style={{ backgroundColor: '#5D4037' }}
          >
            Adicionar cliente
          </button>
        </div>
      </motion.div>
    </div>
  );
}