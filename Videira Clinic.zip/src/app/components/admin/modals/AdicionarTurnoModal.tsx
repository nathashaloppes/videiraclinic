import { useState } from 'react';
import { X } from 'lucide-react';
import { motion } from 'motion/react';

interface AdicionarTurnoModalProps {
  onClose: () => void;
  onSave: (turno: {
    periodo: string;
    inicio: string;
    fim: string;
    valor: number;
  }) => void;
}

export function AdicionarTurnoModal({ onClose, onSave }: AdicionarTurnoModalProps) {
  const [periodo, setPeriodo] = useState('');
  const [inicio, setInicio] = useState('18:00');
  const [fim, setFim] = useState('19:00');
  const [valor, setValor] = useState('');

  const periodos = [
    'Turno Manhã',
    'Turno Tarde',
    'Turno Noite',
    'Turno Madrugada',
    'Hora Avulsa'
  ];

  const formatValor = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const numberValue = parseFloat(numbers) / 100;
    return numberValue.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatValor(e.target.value);
    setValor(formatted);
  };

  const parseValor = (formatted: string): number => {
    const numbers = formatted.replace(/\D/g, '');
    if (!numbers) return 0;
    return parseFloat(numbers);
  };

  const handleSalvar = () => {
    if (!periodo || !inicio || !fim) return;

    onSave({
      periodo,
      inicio,
      fim,
      valor: parseValor(valor),
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg flex items-center gap-2" style={{ color: '#5D4037' }}>
            <span className="text-2xl">+</span> Adicionar turno
          </h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" style={{ color: '#5D4037' }} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Período
            </label>
            <select
              value={periodo}
              onChange={(e) => setPeriodo(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723', backgroundColor: 'white' }}
            >
              <option value="">Selecione um período</option>
              {periodos.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Início e Fim
            </label>
            <div className="flex gap-3 items-center">
              <input
                type="time"
                value={inicio}
                onChange={(e) => setInicio(e.target.value)}
                className="flex-1 px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
              <span style={{ color: '#8D6E63' }}>-</span>
              <input
                type="time"
                value={fim}
                onChange={(e) => setFim(e.target.value)}
                className="flex-1 px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Valor
            </label>
            <input
              type="text"
              placeholder="R$ 0,00"
              value={valor}
              onChange={handleValorChange}
              autoComplete="transaction-amount"
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            />
          </div>

          <button
            onClick={handleSalvar}
            disabled={!periodo || !inicio || !fim}
            className="w-full py-3 rounded-full text-white disabled:opacity-50"
            style={{ backgroundColor: '#5D4037' }}
          >
            Salvar
          </button>
        </div>
      </motion.div>
    </div>
  );
}