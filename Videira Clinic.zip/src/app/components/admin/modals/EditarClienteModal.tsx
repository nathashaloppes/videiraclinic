import { useState } from 'react';
import { X, User } from 'lucide-react';
import { motion } from 'motion/react';
import { type Cliente } from '../../../contexts/AdminContext';

interface EditarClienteModalProps {
  cliente: Cliente;
  onClose: () => void;
  onSave: (cliente: Cliente) => void;
}

export function EditarClienteModal({ cliente, onClose, onSave }: EditarClienteModalProps) {
  // Tentar parsear o endereço existente
  const parseEndereco = (enderecoCompleto: string) => {
    // Formato esperado: "Rua X, 123, Complemento, Bairro, Cidade - UF, CEP"
    const partes = enderecoCompleto.split(', ');
    
    return {
      rua: partes[0] || '',
      numero: '',
      complemento: '',
      bairro: '',
      cidade: '',
      estado: '',
      cep: partes[partes.length - 1] || '',
    };
  };

  const enderecoParseado = parseEndereco(cliente.endereco);

  const [nomeCompleto, setNomeCompleto] = useState(cliente.nomeCompleto);
  const [dataNascimento, setDataNascimento] = useState(cliente.dataNascimento);
  const [telefone, setTelefone] = useState(cliente.telefone);
  const [email, setEmail] = useState(cliente.email);
  const [registroCRO] = useState(cliente.registroCRO);
  const [areaAtuacao, setAreaAtuacao] = useState(cliente.areaAtuacao);
  const [rua, setRua] = useState(enderecoParseado.rua);
  const [numero, setNumero] = useState(enderecoParseado.numero);
  const [complemento, setComplemento] = useState(enderecoParseado.complemento);
  const [bairro, setBairro] = useState(enderecoParseado.bairro);
  const [cidade, setCidade] = useState(enderecoParseado.cidade);
  const [estado, setEstado] = useState(enderecoParseado.estado);
  const [cep, setCep] = useState(enderecoParseado.cep);

  const iniciais = cliente.nomeCompleto
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const formatTelefone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return numbers.replace(/(\d{2})(\d+)/, '($1)$2');
    if (numbers.length <= 11) return numbers.replace(/(\d{2})(\d{5})(\d+)/, '($1)$2-$3');
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1)$2-$3');
  };

  const formatDataNascimento = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 4) return numbers.replace(/(\d{2})(\d+)/, '$1/$2');
    return numbers.replace(/(\d{2})(\d{2})(\d+)/, '$1/$2/$3').substring(0, 10);
  };

  const formatCep = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 5) return numbers;
    return numbers.replace(/(\d{5})(\d+)/, '$1-$2').substring(0, 9);
  };

  const handleCEPChange = async (value: string) => {
    const formatted = formatCep(value);
    setCep(formatted);

    // Se CEP estiver completo, buscar endereço
    const numbers = formatted.replace(/\D/g, '');
    if (numbers.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${numbers}/json/`);
        const data = await response.json();
        
        if (!data.erro) {
          setRua(data.logradouro || '');
          setBairro(data.bairro || '');
          setCidade(data.localidade || '');
          setEstado(data.uf || '');
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  const handleSalvar = () => {
    const enderecoCompleto = [
      rua && numero ? `${rua}, ${numero}` : rua || numero,
      complemento,
      bairro,
      cidade && estado ? `${cidade} - ${estado}` : cidade || estado,
      cep
    ].filter(Boolean).join(', ');

    onSave({
      ...cliente,
      nomeCompleto,
      email,
      telefone,
      areaAtuacao,
      dataNascimento,
      endereco: enderecoCompleto,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg flex items-center gap-2" style={{ color: '#5D4037' }}>
            <span className="text-2xl">+</span> Alterar informações
          </h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" style={{ color: '#5D4037' }} />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col items-center mb-4">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center text-white text-xl"
              style={{ backgroundColor: '#BCAAA4' }}
            >
              {iniciais}
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Nome completo
            </label>
            <input
              type="text"
              value={nomeCompleto}
              disabled
              className="w-full px-4 py-3 rounded-2xl border text-sm bg-gray-50 cursor-not-allowed"
              style={{ borderColor: '#E0E0E0', color: '#9E9E9E' }}
            />
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Registro CRO
            </label>
            <input
              type="text"
              value={registroCRO}
              disabled
              className="w-full px-4 py-3 rounded-2xl border text-sm bg-gray-50 cursor-not-allowed"
              style={{ borderColor: '#E0E0E0', color: '#9E9E9E' }}
            />
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Área de atuação
            </label>
            <input
              type="text"
              value={areaAtuacao}
              onChange={(e) => setAreaAtuacao(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                Data de nascimento
              </label>
              <input
                type="text"
                value={dataNascimento}
                onChange={(e) => setDataNascimento(formatDataNascimento(e.target.value))}
                placeholder="dd/mm/aaaa"
                autoComplete="bday"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                Contato
              </label>
              <input
                type="tel"
                value={telefone}
                onChange={(e) => setTelefone(formatTelefone(e.target.value))}
                placeholder="(00)00000-0000"
                autoComplete="tel"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              E-mail
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            />
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Endereço completo
            </label>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Rua"
                value={rua}
                onChange={(e) => setRua(e.target.value)}
                autoComplete="address-line1"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
              
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Número"
                  value={numero}
                  onChange={(e) => setNumero(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
                <input
                  type="text"
                  placeholder="Complemento"
                  value={complemento}
                  onChange={(e) => setComplemento(e.target.value)}
                  autoComplete="address-line2"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <input
                type="text"
                placeholder="Bairro"
                value={bairro}
                onChange={(e) => setBairro(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />

              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Cidade"
                  value={cidade}
                  onChange={(e) => setCidade(e.target.value)}
                  autoComplete="address-level2"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
                <input
                  type="text"
                  placeholder="Estado"
                  value={estado}
                  onChange={(e) => setEstado(e.target.value)}
                  autoComplete="address-level1"
                  maxLength={2}
                  className="w-full px-4 py-3 rounded-2xl border text-sm uppercase"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <input
                type="text"
                placeholder="CEP"
                value={cep}
                onChange={(e) => handleCEPChange(e.target.value)}
                autoComplete="postal-code"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>
          </div>

          <button
            onClick={handleSalvar}
            className="w-full py-3 rounded-full text-white"
            style={{ backgroundColor: '#5D4037' }}
          >
            Alterar
          </button>
        </div>
      </motion.div>
    </div>
  );
}