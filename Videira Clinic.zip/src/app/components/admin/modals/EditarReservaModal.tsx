import { useState, useEffect } from 'react';
import { X, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'motion/react';
import { CalendarioAdminModal } from '../../CalendarioAdminModal';
import { type Reserva } from '../../../contexts/AdminContext';
import { db } from '../../../services/database';
import { toast } from 'sonner';

interface EditarReservaModalProps {
  reserva: Reserva;
  onClose: () => void;
  onSave: (reserva: Reserva) => void;
  onCancel?: () => void;
}

export function EditarReservaModal({ reserva, onClose, onSave, onCancel }: EditarReservaModalProps) {
  const [data, setData] = useState(reserva.data);
  const [periodo, setPeriodo] = useState('Turno Manhã');
  const [inicio, setInicio] = useState(reserva.inicio);
  const [fim, setFim] = useState(reserva.fim);
  const [valor, setValor] = useState((reserva.valor / 100).toFixed(2).replace('.', ','));
  const [calendarioAberto, setCalendarioAberto] = useState(false);
  const [mostrarConfirmacaoCancelar, setMostrarConfirmacaoCancelar] = useState(false);

  // Carregar período da reserva do banco de dados
  useEffect(() => {
    const dbReserva = db.getReservaById(reserva.id);
    if (dbReserva?.periodo) {
      setPeriodo(dbReserva.periodo);
    }
  }, [reserva.id]);

  const iniciais = reserva.clienteNome
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const formatValor = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const numberValue = parseFloat(numbers) / 100;
    return numberValue.toFixed(2).replace('.', ',');
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatValor(e.target.value);
    setValor(formatted);
  };

  const parseValor = (formatted: string): number => {
    const numbers = formatted.replace(/\D/g, '');
    if (!numbers) return 0;
    return parseFloat(numbers);
  };

  const handleSalvar = () => {
    const valorNumerico = parseValor(valor);

    // Liberar turnos antigos (passando o ID da reserva para excluir da verificação)
    const dataAntigaFormatada = format(reserva.data, 'yyyy-MM-dd');
    db.liberarTurnos(dataAntigaFormatada, reserva.inicio, reserva.fim, reserva.id);

    // Atualizar reserva no banco de dados
    const dataNovaFormatada = format(data, 'yyyy-MM-dd');
    db.updateReserva(reserva.id, {
      data: dataNovaFormatada,
      periodo,
      inicio,
      fim,
      valor: valorNumerico,
    });

    // Marcar novos turnos como reservados
    db.marcarTurnosComoReservados(dataNovaFormatada, inicio, fim);

    // Calcular diferença de valor para ajuste de crédito
    const diferencaValor = reserva.valor - valorNumerico;
    if (diferencaValor > 0) {
      // Nova reserva é mais barata, adicionar crédito
      db.adicionarCredito(
        reserva.clienteId,
        diferencaValor,
        'Crédito gerado por alteração de reserva pelo administrador',
        reserva.id
      );
    } else if (diferencaValor < 0) {
      // Nova reserva é mais cara, debitar crédito
      const valorADebitar = Math.abs(diferencaValor);
      const sucesso = db.debitarCredito(
        reserva.clienteId,
        valorADebitar,
        'Débito por alteração de reserva pelo administrador',
        reserva.id
      );

      if (!sucesso) {
        toast.error('Cliente não possui crédito suficiente para esta alteração');
        return;
      }
    }

    window.dispatchEvent(new CustomEvent('reservaAtualizada', {
      detail: { reservaId: reserva.id }
    }));
    toast.success('Reserva alterada com sucesso!');

    onSave({
      ...reserva,
      data,
      inicio,
      fim,
      valor: valorNumerico,
    });
  };

  const handleCancelarReserva = () => {
    // Liberar turnos
    const dataFormatada = format(reserva.data, 'yyyy-MM-dd');
    db.liberarTurnos(dataFormatada, reserva.inicio, reserva.fim);

    // Retornar crédito ao cliente
    db.adicionarCredito(
      reserva.clienteId,
      reserva.valor,
      'Estorno de cancelamento pelo administrador',
      reserva.id
    );

    // Atualizar status da reserva no banco de dados
    db.updateReserva(reserva.id, { status: 'cancelada' });

    // Emitir evento de cancelamento
    window.dispatchEvent(new CustomEvent('reservaCancelada', {
      detail: { reservaId: reserva.id }
    }));

    toast.success('Reserva cancelada e crédito estornado ao cliente');
    setMostrarConfirmacaoCancelar(false);

    if (onCancel) {
      onCancel();
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg flex items-center gap-2" style={{ color: '#5D4037' }}>
            <span className="text-2xl">+</span> Alterar reserva
          </h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" style={{ color: '#5D4037' }} />
          </button>
        </div>

        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center text-white text-lg"
              style={{ backgroundColor: '#BCAAA4' }}
            >
              {iniciais}
            </div>
            <div>
              <h3 style={{ color: '#3E2723' }}>{reserva.clienteNome}</h3>
              <p className="text-sm text-gray-500">{reserva.clienteEmail}</p>
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Data
            </label>
            <button
              onClick={() => setCalendarioAberto(true)}
              className="w-full px-4 py-3 rounded-2xl border text-sm text-left relative"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            >
              {format(data, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
              <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#8D6E63' }} />
            </button>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Período
            </label>
            <select
              value={periodo}
              onChange={(e) => setPeriodo(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            >
              <option value="Turno Manhã">Turno Manhã</option>
              <option value="Turno Tarde">Turno Tarde</option>
              <option value="Turno Noite">Turno Noite</option>
              <option value="Turno Madrugada">Turno Madrugada</option>
              <option value="Hora Avulsa">Hora Avulsa</option>
            </select>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Início e Fim
            </label>
            <div className="flex gap-3 items-center">
              <input
                type="time"
                value={inicio}
                onChange={(e) => setInicio(e.target.value)}
                className="flex-1 px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
              <span style={{ color: '#8D6E63' }}>-</span>
              <input
                type="time"
                value={fim}
                onChange={(e) => setFim(e.target.value)}
                className="flex-1 px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
              Valor
            </label>
            <input
              type="text"
              placeholder="R$ 0,00"
              value={`R$ ${valor}`}
              onChange={handleValorChange}
              autoComplete="transaction-amount"
              className="w-full px-4 py-3 rounded-2xl border text-sm"
              style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
            />
          </div>

          <button
            onClick={handleSalvar}
            className="w-full py-3 rounded-full text-white"
            style={{ backgroundColor: '#5D4037' }}
          >
            Alterar
          </button>

          <button
            onClick={() => setMostrarConfirmacaoCancelar(true)}
            className="w-full py-3 rounded-full border-2 mt-3"
            style={{ borderColor: '#D32F2F', color: '#D32F2F' }}
          >
            Cancelar reserva
          </button>
        </div>
      </motion.div>

      {mostrarConfirmacaoCancelar && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-8 shadow-xl max-w-sm w-full"
          >
            <h3 className="text-lg mb-4 text-center" style={{ color: '#5D4037' }}>
              Cancelar reserva?
            </h3>
            <p className="text-sm mb-6 text-center" style={{ color: '#8D6E63' }}>
              O valor de R$ {(reserva.valor / 100).toFixed(2).replace('.', ',')} será retornado como crédito para o cliente.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setMostrarConfirmacaoCancelar(false)}
                className="flex-1 py-3 rounded-full border-2"
                style={{ borderColor: '#5D4037', color: '#5D4037' }}
              >
                Não
              </button>
              <button
                onClick={handleCancelarReserva}
                className="flex-1 py-3 rounded-full text-white"
                style={{ backgroundColor: '#D32F2F' }}
              >
                Sim, cancelar
              </button>
            </div>
          </motion.div>
        </div>
      )}

      <CalendarioAdminModal
        isOpen={calendarioAberto}
        onClose={() => setCalendarioAberto(false)}
        onSelectDate={(novaData) => {
          setData(novaData);
          setCalendarioAberto(false);
        }}
        selectedDate={data}
      />
    </div>
  );
}