import { AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';

interface ErroTurnoModalProps {
  onClose: () => void;
  mensagem?: string;
}

export function ErroTurnoModal({ onClose, mensagem }: ErroTurnoModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[70] p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-xl text-center"
      >
        <div className="flex flex-col items-center gap-4">
          <AlertTriangle className="w-12 h-12" style={{ color: '#F57C00' }} />

          <div>
            <p style={{ color: '#3E2723' }}>
              {mensagem || 'Já existe um turno disponível nesse horário.'}
            </p>
          </div>

          <button
            onClick={onClose}
            className="mt-4 px-6 py-2 rounded-full text-sm"
            style={{ backgroundColor: '#5D4037', color: 'white' }}
          >
            Entendi
          </button>
        </div>
      </motion.div>
    </div>
  );
}