import { motion } from 'motion/react';

interface ExcluirTurnoModalProps {
  onClose: () => void;
  onConfirm: () => void;
}

export function ExcluirTurnoModal({ onClose, onConfirm }: ExcluirTurnoModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[70] p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-xl text-center"
      >
        <h3 className="text-lg mb-6" style={{ color: '#5D4037' }}>
          Tem certeza que deseja excluir esse item?
        </h3>

        <div className="flex gap-4">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-full border-2"
            style={{ borderColor: '#5D4037', color: '#5D4037' }}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-3 rounded-full text-white"
            style={{ backgroundColor: '#5D4037' }}
          >
            Excluir
          </button>
        </div>
      </motion.div>
    </div>
  );
}
