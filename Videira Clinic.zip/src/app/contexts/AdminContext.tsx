import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { db } from '../services/database';

export interface Reserva {
  id: string;
  clienteId: string;
  clienteNome: string;
  clienteEmail: string;
  clienteFoto?: string;
  data: Date;
  periodo?: string;
  inicio: string;
  fim: string;
  valor: number;
  turnosIds?: string[]; // IDs dos turnos reservados para poder reativá-los ao excluir
}

export interface Cliente {
  id: string;
  nomeCompleto: string;
  email: string;
  telefone: string;
  registroCRO: string;
  areaAtuacao: string;
  dataNascimento: string;
  endereco: string;
  fotoPerfil?: string;
  numeroReservas: number;
}

export interface Turno {
  id: string;
  periodo: string;
  inicio: string;
  fim: string;
  valor: number;
  ativo: boolean;
}

export interface TurnoPorData {
  data: string; // YYYY-MM-DD format
  turnos: Turno[];
}

interface AdminContextType {
  reservas: Reserva[];
  clientes: Cliente[];
  turnosPorData: TurnoPorData[];
  adicionarReserva: (reserva: Omit<Reserva, 'id'>) => void;
  atualizarReserva: (id: string, reserva: Partial<Reserva>) => void;
  excluirReserva: (id: string) => void;
  obterReservasPorCliente: (clienteId: string) => Reserva[];
  adicionarCliente: (cliente: Omit<Cliente, 'id' | 'numeroReservas'>) => void;
  atualizarCliente: (id: string, cliente: Partial<Cliente>) => void;
  excluirCliente: (id: string) => boolean; // Retorna false se houver reservas futuras
  obterTurnosPorData: (data: Date) => Turno[];
  adicionarTurnoNaData: (data: Date, turno: Omit<Turno, 'id' | 'ativo'>) => boolean; // Retorna false se houver conflito
  atualizarTurnoNaData: (data: Date, turnoId: string, turno: Partial<Turno>) => void;
  excluirTurnoNaData: (data: Date, turnoId: string) => boolean; // Retorna false se o turno estiver reservado
  ativarDesativarTurnoNaData: (data: Date, turnoId: string) => boolean; // retorna false se houver conflito
  reordenarTurnosNaData: (data: Date, turnoIdOrigem: string, turnoIdDestino: string) => void;
  salvarOrdemTurnos: (data: Date, turnosOrdenados: Turno[]) => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [reservas, setReservas] = useState<Reserva[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [turnosPorData, setTurnosPorData] = useState<TurnoPorData[]>([]);

  // Carregar dados do banco de dados ao iniciar
  useEffect(() => {
    // Carregar clientes
    const dbUsers = db.getAllUsers().filter(u => !u.isAdmin);
    const clientesCarregados = dbUsers.map(u => ({
      id: u.id,
      nomeCompleto: u.nomeCompleto,
      email: u.email,
      telefone: u.telefone,
      registroCRO: u.registroCRO,
      areaAtuacao: u.areaAtuacao,
      dataNascimento: u.dataNascimento || '',
      endereco: u.endereco || '',
      fotoPerfil: u.fotoPerfil,
      numeroReservas: db.getReservasByUserId(u.id).length,
    }));
    setClientes(clientesCarregados);

    // Carregar turnos
    const dbTurnos = db.getAllTurnos();
    const turnosPorDataMap = new Map<string, Turno[]>();

    dbTurnos.forEach(t => {
      const turno: Turno = {
        id: t.id,
        periodo: t.periodo,
        inicio: t.inicio,
        fim: t.fim,
        valor: t.valor,
        ativo: t.ativo,
      };

      const existing = turnosPorDataMap.get(t.data) || [];
      existing.push(turno);
      turnosPorDataMap.set(t.data, existing);
    });

    const turnosCarregados: TurnoPorData[] = Array.from(turnosPorDataMap.entries()).map(([data, turnos]) => ({
      data,
      turnos,
    }));

    setTurnosPorData(turnosCarregados);

    // Carregar reservas
    const dbReservas = db.getAllReservas().filter(r => r.status === 'confirmada');
    const reservasCarregadas = dbReservas.map(r => {
      const cliente = dbUsers.find(u => u.id === r.userId);
      return {
        id: r.id,
        clienteId: r.userId,
        clienteNome: cliente?.nomeCompleto || 'Cliente desconhecido',
        clienteEmail: cliente?.email || '',
        clienteFoto: cliente?.fotoPerfil,
        data: new Date(r.data + 'T00:00:00'),
        inicio: r.inicio,
        fim: r.fim,
        valor: r.valor,
      };
    });
    setReservas(reservasCarregadas);
  }, []);

  // Funções auxiliares
  const formatarDataString = (data: Date): string => {
    const ano = data.getFullYear();
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const dia = String(data.getDate()).padStart(2, '0');
    return `${ano}-${mes}-${dia}`;
  };

  const horarioDentroDeOutro = (inicio1: string, fim1: string, inicio2: string, fim2: string): boolean => {
    const [h1i, m1i] = inicio1.split(':').map(Number);
    const [h1f, m1f] = fim1.split(':').map(Number);
    const [h2i, m2i] = inicio2.split(':').map(Number);
    const [h2f, m2f] = fim2.split(':').map(Number);

    const min1i = h1i * 60 + m1i;
    const min1f = h1f * 60 + m1f;
    const min2i = h2i * 60 + m2i;
    const min2f = h2f * 60 + m2f;

    return (min1i < min2f && min1f > min2i);
  };

  // Expor turnos globalmente para ReservasContext
  useEffect(() => {
    (window as any).__turnosPorData = turnosPorData;
  }, [turnosPorData]);

  // Expor reservas globalmente para ReservasContext
  useEffect(() => {
    (window as any).__reservasAdmin = reservas;
  }, [reservas]);

  // Escutar eventos de novos clientes
  useEffect(() => {
    const handleNovoCliente = (event: any) => {
      const { cliente: novoCliente } = event.detail;

      // Verificar se o cliente já existe
      setClientes(prev => {
        const jaExiste = prev.find(c => c.id === novoCliente.id);
        if (jaExiste) return prev;

        // Adicionar novo cliente
        return [
          ...prev,
          {
            id: novoCliente.id,
            nomeCompleto: novoCliente.nomeCompleto,
            email: novoCliente.email,
            telefone: novoCliente.telefone,
            dataNascimento: novoCliente.dataNascimento || '',
            endereco: novoCliente.endereco || '',
            fotoPerfil: novoCliente.fotoPerfil,
            numeroReservas: 0,
          },
        ];
      });
    };

    window.addEventListener('novoCliente', handleNovoCliente);

    return () => {
      window.removeEventListener('novoCliente', handleNovoCliente);
    };
  }, []);

  // Escutar eventos de novas reservas criadas na versão do cliente
  useEffect(() => {
    const handleNovaReserva = (event: any) => {
      const { reservas: novasReservas, userId, user } = event.detail;

      // Buscar informações do cliente
      let cliente = clientes.find(c => c.id === userId);

      // Se o cliente não existir, adicioná-lo automaticamente
      if (!cliente && user) {
        const novoCliente = {
          id: user.id,
          nomeCompleto: user.nomeCompleto,
          email: user.email,
          telefone: user.telefone,
          dataNascimento: user.dataNascimento || '',
          endereco: user.endereco || '',
          fotoPerfil: user.fotoPerfil,
          numeroReservas: 0,
        };

        setClientes(prev => [...prev, novoCliente]);
        cliente = novoCliente;
      }

      if (!cliente) return;

      // Converter reservas do formato do cliente para o formato admin
      novasReservas.forEach((reservaCliente: any) => {
        const horarios = reservaCliente.turnos.map((t: any) => t.horario);
        const primeiroHorario = horarios[0] || '';
        const ultimoHorario = horarios[horarios.length - 1] || '';

        // Extrair início e fim
        const match1 = primeiroHorario.match(/(\d+)h/);
        const match2 = ultimoHorario.match(/às (\d+)h/);

        const inicio = match1 ? `${match1[1].padStart(2, '0')}:00` : '00:00';
        const fim = match2 ? `${match2[1].padStart(2, '0')}:00` : '00:00';

        // Pegar IDs dos turnos para poder reativá-los depois
        const turnosIds = reservaCliente.turnos.map((t: any) => t.id);

        const reservaAdmin: Reserva = {
          id: reservaCliente.id,
          clienteId: userId,
          clienteNome: cliente.nomeCompleto,
          clienteEmail: cliente.email,
          clienteFoto: cliente.fotoPerfil,
          data: reservaCliente.data,
          inicio,
          fim,
          valor: reservaCliente.total,
          turnosIds,
        };

        setReservas(prev => [...prev, reservaAdmin]);

        // Desativar os turnos que foram reservados
        const dataString = formatarDataString(reservaCliente.data);

        setTurnosPorData(prev =>
          prev.map(t =>
            t.data === dataString
              ? {
                  ...t,
                  turnos: t.turnos.map(turno =>
                    turnosIds.includes(turno.id) ? { ...turno, ativo: false } : turno
                  ),
                }
              : t
          )
        );
      });

      // Emitir evento para ReservasContext sincronizar
      window.dispatchEvent(new CustomEvent('turnosAtualizados'));

      // Atualizar contador de reservas do cliente
      setClientes(prev =>
        prev.map(c =>
          c.id === userId
            ? { ...c, numeroReservas: c.numeroReservas + novasReservas.length }
            : c
        )
      );
    };

    window.addEventListener('novaReserva', handleNovaReserva);

    return () => {
      window.removeEventListener('novaReserva', handleNovaReserva);
    };
  }, [clientes]);

  // Listener para atualização de reservas
  useEffect(() => {
    const handleReservaAtualizada = (event: any) => {
      const { reservaId } = event.detail;
      const dbReserva = db.getReservaById(reservaId);

      if (dbReserva) {
        setReservas(prev => prev.map(r => {
          if (r.id === reservaId) {
            return {
              ...r,
              data: new Date(dbReserva.data + 'T00:00:00'),
              inicio: dbReserva.inicio,
              fim: dbReserva.fim,
              valor: dbReserva.valor,
            };
          }
          return r;
        }));

        // Recarregar turnos do banco de dados para sincronizar
        const dbTurnos = db.getAllTurnos();
        const turnosPorDataMap = new Map<string, Turno[]>();

        dbTurnos.forEach(t => {
          const turno: Turno = {
            id: t.id,
            periodo: t.periodo,
            inicio: t.inicio,
            fim: t.fim,
            valor: t.valor,
            ativo: t.ativo,
          };

          const existing = turnosPorDataMap.get(t.data) || [];
          existing.push(turno);
          turnosPorDataMap.set(t.data, existing);
        });

        const turnosCarregados: TurnoPorData[] = Array.from(turnosPorDataMap.entries()).map(([data, turnos]) => ({
          data,
          turnos,
        }));

        setTurnosPorData(turnosCarregados);
      }
    };

    window.addEventListener('reservaAtualizada', handleReservaAtualizada);
    return () => window.removeEventListener('reservaAtualizada', handleReservaAtualizada);
  }, []);

  // Listener para cancelamento de reservas
  useEffect(() => {
    const handleReservaCancelada = (event: any) => {
      const { reservaId } = event.detail;

      // Encontrar a reserva antes de removê-la
      const reservaCancelada = reservas.find(r => r.id === reservaId);

      // Remover reserva da lista
      setReservas(prev => prev.filter(r => r.id !== reservaId));

      // Atualizar contador de reservas do cliente
      if (reservaCancelada) {
        setClientes(prev =>
          prev.map(c =>
            c.id === reservaCancelada.clienteId
              ? { ...c, numeroReservas: Math.max(0, c.numeroReservas - 1) }
              : c
          )
        );

        // Reativar turnos que foram desativados por causa desta reserva
        const dataString = formatarDataString(reservaCancelada.data);
        const dbTurnos = db.getTurnosByData(dataString);
        const reservasRestantes = reservas.filter(r =>
          r.id !== reservaId &&
          formatarDataString(r.data) === dataString
        );

        dbTurnos.forEach(turno => {
          // Verificar se o turno colide com a reserva cancelada
          const colidiaComReservaCancelada = horarioDentroDeOutro(
            turno.inicio, turno.fim,
            reservaCancelada.inicio, reservaCancelada.fim
          );

          if (colidiaComReservaCancelada && !turno.ativo) {
            // Verificar se não há outras reservas ou turnos ativos que colidem
            const temOutraReserva = reservasRestantes.some(r =>
              horarioDentroDeOutro(turno.inicio, turno.fim, r.inicio, r.fim)
            );

            const temOutroTurnoAtivo = dbTurnos.some(outroTurno =>
              outroTurno.id !== turno.id &&
              outroTurno.ativo &&
              horarioDentroDeOutro(turno.inicio, turno.fim, outroTurno.inicio, outroTurno.fim)
            );

            // Se não houver colisões, reativar o turno
            if (!temOutraReserva && !temOutroTurnoAtivo) {
              db.updateTurno(turno.id, { ativo: true });
            }
          }
        });
      }

      // Recarregar turnos do banco de dados para sincronizar
      const dbTurnos = db.getAllTurnos();
      const turnosPorDataMap = new Map<string, Turno[]>();

      dbTurnos.forEach(t => {
        const turno: Turno = {
          id: t.id,
          periodo: t.periodo,
          inicio: t.inicio,
          fim: t.fim,
          valor: t.valor,
          ativo: t.ativo,
        };

        const existing = turnosPorDataMap.get(t.data) || [];
        existing.push(turno);
        turnosPorDataMap.set(t.data, existing);
      });

      const turnosCarregados: TurnoPorData[] = Array.from(turnosPorDataMap.entries()).map(([data, turnos]) => ({
        data,
        turnos,
      }));

      setTurnosPorData(turnosCarregados);
    };

    window.addEventListener('reservaCancelada', handleReservaCancelada);
    return () => window.removeEventListener('reservaCancelada', handleReservaCancelada);
  }, [reservas, clientes]);

  const adicionarReserva = (novaReserva: Omit<Reserva, 'id'>) => {
    const dataString = formatarDataString(novaReserva.data);

    // Salvar no banco de dados
    const dbReserva = db.createReserva({
      userId: novaReserva.clienteId,
      data: dataString,
      inicio: novaReserva.inicio,
      fim: novaReserva.fim,
      periodo: novaReserva.periodo || `${novaReserva.inicio} às ${novaReserva.fim}`,
      valor: novaReserva.valor,
      status: 'confirmada',
    });

    // Marcar turnos como reservados no banco de dados
    db.marcarTurnosComoReservados(dataString, novaReserva.inicio, novaReserva.fim);

    const reserva: Reserva = {
      ...novaReserva,
      id: dbReserva.id,
    };

    setReservas([...reservas, reserva]);

    // Atualizar contador de reservas do cliente
    setClientes(
      clientes.map((c) =>
        c.id === reserva.clienteId
          ? { ...c, numeroReservas: c.numeroReservas + 1 }
          : c
      )
    );

    // Desativar turnos na data da reserva que coincidem com o horário (para o estado local)
    const turnosDesativadosIds: string[] = [];

    setTurnosPorData(prev =>
      prev.map(t => {
        if (t.data === dataString) {
          const turnosAtualizados = t.turnos.map(turno => {
            // Verificar se o turno está dentro do horário da reserva
            if (horarioDentroDeOutro(turno.inicio, turno.fim, reserva.inicio, reserva.fim)) {
              turnosDesativadosIds.push(turno.id);
              return { ...turno, ativo: false };
            }
            return turno;
          });
          return { ...t, turnos: turnosAtualizados };
        }
        return t;
      })
    );

    // Atualizar a reserva com os IDs dos turnos desativados se ainda não tiver
    if (!reserva.turnosIds || reserva.turnosIds.length === 0) {
      reserva.turnosIds = turnosDesativadosIds;
      setReservas(prev => prev.map(r => r.id === reserva.id ? reserva : r));
    }

    // Emitir eventos para sincronizar
    window.dispatchEvent(new CustomEvent('reservaCriada', {
      detail: { reserva: dbReserva, userId: novaReserva.clienteId }
    }));
    window.dispatchEvent(new CustomEvent('turnosAtualizados'));
  };

  const atualizarReserva = (id: string, reservaAtualizada: Partial<Reserva>) => {
    const reservaAntiga = reservas.find((r) => r.id === id);
    
    if (reservaAntiga) {
      // Verificar se a data ou horário mudou
      const dataMudou = reservaAtualizada.data && formatarDataString(reservaAtualizada.data) !== formatarDataString(reservaAntiga.data);
      const horarioMudou = (reservaAtualizada.inicio && reservaAtualizada.inicio !== reservaAntiga.inicio) ||
                          (reservaAtualizada.fim && reservaAtualizada.fim !== reservaAntiga.fim);
      
      if (dataMudou || horarioMudou) {
        // Reativar os turnos antigos
        if (reservaAntiga.turnosIds && reservaAntiga.turnosIds.length > 0) {
          const dataAntiga = formatarDataString(reservaAntiga.data);
          setTurnosPorData(prev =>
            prev.map(t =>
              t.data === dataAntiga
                ? {
                    ...t,
                    turnos: t.turnos.map(turno =>
                      reservaAntiga.turnosIds!.includes(turno.id) ? { ...turno, ativo: true } : turno
                    ),
                  }
                : t
            )
          );
        }

        // Desativar os novos turnos e coletar seus IDs
        const novaData = reservaAtualizada.data || reservaAntiga.data;
        const novoInicio = reservaAtualizada.inicio || reservaAntiga.inicio;
        const novoFim = reservaAtualizada.fim || reservaAntiga.fim;
        const dataNovaString = formatarDataString(novaData);
        const novosTurnosIds: string[] = [];

        setTurnosPorData(prev =>
          prev.map(t => {
            if (t.data === dataNovaString) {
              const turnosAtualizados = t.turnos.map(turno => {
                // Verificar se o turno está dentro do novo horário da reserva
                if (horarioDentroDeOutro(turno.inicio, turno.fim, novoInicio, novoFim)) {
                  novosTurnosIds.push(turno.id);
                  return { ...turno, ativo: false };
                }
                return turno;
              });
              return { ...t, turnos: turnosAtualizados };
            }
            return t;
          })
        );

        // Atualizar a reserva com os novos IDs de turnos
        reservaAtualizada.turnosIds = novosTurnosIds;

        // Emitir evento para ReservasContext sincronizar
        window.dispatchEvent(new CustomEvent('turnosAtualizados'));
      }
    }

    setReservas(
      reservas.map((r) => (r.id === id ? { ...r, ...reservaAtualizada } : r))
    );
  };

  const excluirReserva = (id: string) => {
    const reserva = reservas.find((r) => r.id === id);
    if (reserva) {
      setReservas(reservas.filter((r) => r.id !== id));

      // Atualizar contador de reservas do cliente
      setClientes(
        clientes.map((c) =>
          c.id === reserva.clienteId
            ? { ...c, numeroReservas: Math.max(0, c.numeroReservas - 1) }
            : c
        )
      );

      // Reativar os turnos que foram reservados
      if (reserva.turnosIds && reserva.turnosIds.length > 0) {
        const dataString = formatarDataString(reserva.data);
        setTurnosPorData(prev =>
          prev.map(t =>
            t.data === dataString
              ? {
                  ...t,
                  turnos: t.turnos.map(turno =>
                    reserva.turnosIds!.includes(turno.id) ? { ...turno, ativo: true } : turno
                  ),
                }
              : t
          )
        );

        // Emitir evento para ReservasContext sincronizar
        window.dispatchEvent(new CustomEvent('turnosAtualizados'));
      }
    }
  };

  const obterReservasPorCliente = (clienteId: string) => {
    return reservas.filter((r) => r.clienteId === clienteId);
  };

  const adicionarCliente = (novoCliente: Omit<Cliente, 'id' | 'numeroReservas'>) => {
    // Criar usuário no banco de dados
    const dbUser = db.createUser({
      nomeCompleto: novoCliente.nomeCompleto,
      email: novoCliente.email,
      senha: '123456', // Senha padrão
      telefone: novoCliente.telefone,
      registroCRO: novoCliente.registroCRO,
      areaAtuacao: novoCliente.areaAtuacao,
      dataNascimento: novoCliente.dataNascimento,
      endereco: novoCliente.endereco,
      fotoPerfil: novoCliente.fotoPerfil,
    });

    const cliente: Cliente = {
      ...novoCliente,
      id: dbUser.id,
      numeroReservas: 0,
    };
    setClientes([cliente, ...clientes]);
  };

  const atualizarCliente = (id: string, clienteAtualizado: Partial<Cliente>) => {
    // Atualizar no banco de dados
    db.updateUser(id, {
      telefone: clienteAtualizado.telefone,
      email: clienteAtualizado.email,
      areaAtuacao: clienteAtualizado.areaAtuacao,
      dataNascimento: clienteAtualizado.dataNascimento,
      endereco: clienteAtualizado.endereco,
      fotoPerfil: clienteAtualizado.fotoPerfil,
    });

    setClientes(
      clientes.map((c) => (c.id === id ? { ...c, ...clienteAtualizado } : c))
    );

    // Atualizar informações do cliente em todas as reservas
    if (clienteAtualizado.nomeCompleto || clienteAtualizado.email) {
      setReservas(
        reservas.map((r) =>
          r.clienteId === id
            ? {
                ...r,
                clienteNome: clienteAtualizado.nomeCompleto || r.clienteNome,
                clienteEmail: clienteAtualizado.email || r.clienteEmail,
              }
            : r
        )
      );
    }

    // Disparar evento para sincronizar com AuthContext
    window.dispatchEvent(new CustomEvent('clienteAtualizadoPorAdmin', {
      detail: { clienteId: id, dados: clienteAtualizado }
    }));
  };

  const excluirCliente = (id: string) => {
    // Verificar se o cliente tem reservas futuras
    const hoje = new Date();
    const reservasFuturas = reservas.filter(r =>
      r.clienteId === id && r.data >= hoje
    );

    if (reservasFuturas.length > 0) {
      return false; // Não pode excluir cliente com reserva futura
    }

    // Verificar se o cliente tem crédito positivo
    const creditoCliente = db.getCredito(id);
    if (creditoCliente > 0) {
      return false; // Não pode excluir cliente com crédito positivo
    }

    setClientes(clientes.filter((c) => c.id !== id));
    // Remover todas as reservas do cliente
    setReservas(reservas.filter((r) => r.clienteId !== id));
    
    return true; // Sucesso
  };

  // Funções de gerenciamento de turnos por data
  const obterTurnosPorData = (data: Date): Turno[] => {
    const dataString = formatarDataString(data);
    const turnosDaData = turnosPorData.find(t => t.data === dataString);
    let turnosConfigurados = turnosDaData ? [...turnosDaData.turnos] : [];

    // Buscar todas as reservas confirmadas na data
    const reservasNaData = reservas.filter(r => formatarDataString(r.data) === dataString);
    const turnosDeReservas: Turno[] = [];

    // Desativar turnos que têm reservas correspondentes
    turnosConfigurados = turnosConfigurados.map(turno => {
      const temReserva = reservasNaData.some(reserva =>
        horarioDentroDeOutro(turno.inicio, turno.fim, reserva.inicio, reserva.fim)
      );

      if (temReserva) {
        return { ...turno, ativo: false };
      }
      return turno;
    });

    reservasNaData.forEach(reserva => {
      // Verificar se já existe um turno configurado para este horário exato
      const turnoExistente = turnosConfigurados.find(t =>
        t.inicio === reserva.inicio && t.fim === reserva.fim
      );

      // Se não existe, criar um turno virtual da reserva
      if (!turnoExistente) {
        // Buscar o período da reserva no banco de dados
        const dbReserva = db.getReservaById(reserva.id);
        const periodoReserva = dbReserva?.periodo || `Reservado - ${reserva.clienteNome}`;

        turnosDeReservas.push({
          id: `reserva_${reserva.id}`,
          periodo: periodoReserva,
          inicio: reserva.inicio,
          fim: reserva.fim,
          valor: reserva.valor,
          ativo: false,
        });
      }
    });

    return [...turnosConfigurados, ...turnosDeReservas];
  };

  const adicionarTurnoNaData = (data: Date, novoTurno: Omit<Turno, 'id' | 'ativo'>) => {
    const dataString = formatarDataString(data);

    // Verificar se já existe um turno ATIVO com horário similar
    const turnosDaData = turnosPorData.find(t => t.data === dataString);
    if (turnosDaData) {
      const turnoAtivoExistente = turnosDaData.turnos.find(
        t => t.ativo && horarioDentroDeOutro(novoTurno.inicio, novoTurno.fim, t.inicio, t.fim)
      );

      if (turnoAtivoExistente) {
        return false; // Já existe um turno ATIVO com horário similar - não pode criar
      }
    }

    // Verificar se já existe uma reserva que colide com este horário
    const reservaColidindo = reservas.some(r =>
      formatarDataString(r.data) === dataString &&
      horarioDentroDeOutro(novoTurno.inicio, novoTurno.fim, r.inicio, r.fim)
    );

    // Se houver reserva colidindo, criar o turno mas já desativado
    const turnoAtivo = !reservaColidindo;

    const turno: Turno = {
      ...novoTurno,
      id: Date.now().toString(),
      ativo: turnoAtivo,
    };

    // Salvar turno no banco de dados
    db.createTurno({
      data: dataString,
      periodo: novoTurno.periodo,
      inicio: novoTurno.inicio,
      fim: novoTurno.fim,
      valor: novoTurno.valor,
      ativo: turnoAtivo,
    });

    setTurnosPorData(prev => {
      const existe = prev.find(t => t.data === dataString);
      if (existe) {
        return prev.map(t =>
          t.data === dataString
            ? { ...t, turnos: [...t.turnos, turno] }
            : t
        );
      } else {
        return [...prev, { data: dataString, turnos: [turno] }];
      }
    });

    // Emitir evento para ReservasContext sincronizar
    window.dispatchEvent(new CustomEvent('turnosAtualizados'));

    return true; // Sucesso
  };

  const atualizarTurnoNaData = (data: Date, turnoId: string, turnoAtualizado: Partial<Turno>) => {
    const dataString = formatarDataString(data);

    // Não permitir editar turnos virtuais de reservas
    if (turnoId.startsWith('reserva_')) {
      return;
    }

    // Atualizar no banco de dados
    db.updateTurno(turnoId, turnoAtualizado);

    setTurnosPorData(prev =>
      prev.map(t =>
        t.data === dataString
          ? {
              ...t,
              turnos: t.turnos.map(turno =>
                turno.id === turnoId ? { ...turno, ...turnoAtualizado } : turno
              ),
            }
          : t
      )
    );

    // Emitir evento para ReservasContext sincronizar
    window.dispatchEvent(new CustomEvent('turnosAtualizados'));
  };

  const excluirTurnoNaData = (data: Date, turnoId: string) => {
    const dataString = formatarDataString(data);

    // Não permitir excluir turnos virtuais de reservas
    if (turnoId.startsWith('reserva_')) {
      return false;
    }

    // Buscar o turno para verificar horário
    const turnosDaData = turnosPorData.find(t => t.data === dataString);
    const turno = turnosDaData?.turnos.find(t => t.id === turnoId);
    if (!turno) return false;

    // Verificar se o turno está reservado (por ID ou por colisão de horário)
    const turnoReservado = reservas.some(r => {
      const dataReserva = formatarDataString(r.data);
      if (dataReserva !== dataString) return false;

      // Verificar por ID
      if (r.turnosIds?.includes(turnoId)) return true;

      // Verificar por colisão de horário
      return horarioDentroDeOutro(turno.inicio, turno.fim, r.inicio, r.fim);
    });

    if (turnoReservado) {
      return false; // Não pode excluir turno reservado
    }

    // Excluir do banco de dados
    db.deleteTurno(turnoId);

    setTurnosPorData(prev =>
      prev.map(t =>
        t.data === dataString
          ? { ...t, turnos: t.turnos.filter(turno => turno.id !== turnoId) }
          : t
      ).filter(t => t.turnos.length > 0)
    );

    // Emitir evento para ReservasContext sincronizar
    window.dispatchEvent(new CustomEvent('turnosAtualizados'));

    return true; // Sucesso
  };

  const ativarDesativarTurnoNaData = (data: Date, turnoId: string): boolean => {
    const dataString = formatarDataString(data);

    // Não permitir ativar/desativar turnos virtuais de reservas
    if (turnoId.startsWith('reserva_')) {
      return false;
    }

    const turnosDaData = turnosPorData.find(t => t.data === dataString);
    if (!turnosDaData) return false;

    const turno = turnosDaData.turnos.find(t => t.id === turnoId);
    if (!turno) return false;

    // Verificar se o turno está reservado (por ID ou por colisão de horário)
    const turnoReservado = reservas.some(r => {
      const dataReserva = formatarDataString(r.data);
      if (dataReserva !== dataString) return false;

      // Verificar por ID
      if (r.turnosIds?.includes(turnoId)) return true;

      // Verificar por colisão de horário
      return horarioDentroDeOutro(turno.inicio, turno.fim, r.inicio, r.fim);
    });

    if (turnoReservado) {
      return false; // Não pode ativar/desativar turno reservado
    }

    // Se está ativando, verificar conflitos
    if (!turno.ativo) {
      const conflito = turnosDaData.turnos.find(
        t => t.id !== turnoId && t.ativo && horarioDentroDeOutro(turno.inicio, turno.fim, t.inicio, t.fim)
      );

      if (conflito) {
        return false; // Retorna false indicando que há conflito
      }
    }

    // Atualizar no banco de dados
    db.updateTurno(turnoId, { ativo: !turno.ativo });

    // Ativar/desativar o turno
    setTurnosPorData(prev =>
      prev.map(t =>
        t.data === dataString
          ? {
              ...t,
              turnos: t.turnos.map(turnoItem =>
                turnoItem.id === turnoId ? { ...turnoItem, ativo: !turnoItem.ativo } : turnoItem
              ),
            }
          : t
      )
    );

    // Emitir evento para ReservasContext sincronizar
    window.dispatchEvent(new CustomEvent('turnosAtualizados'));

    return true; // Sucesso
  };

  const reordenarTurnosNaData = (data: Date, turnoIdOrigem: string, turnoIdDestino: string): void => {
    const dataString = formatarDataString(data);

    setTurnosPorData(prev =>
      prev.map(t => {
        if (t.data === dataString) {
          const turnos = [...t.turnos];
          const indexOrigem = turnos.findIndex(turno => turno.id === turnoIdOrigem);
          const indexDestino = turnos.findIndex(turno => turno.id === turnoIdDestino);

          if (indexOrigem === -1 || indexDestino === -1) return t;

          // Remover o item da posição original
          const [itemMovido] = turnos.splice(indexOrigem, 1);

          // Inserir na nova posição
          turnos.splice(indexDestino, 0, itemMovido);

          return { ...t, turnos };
        }
        return t;
      })
    );

    // Emitir evento para sincronizar
    window.dispatchEvent(new CustomEvent('turnosAtualizados'));
  };

  const salvarOrdemTurnos = (data: Date, turnosOrdenados: Turno[]): void => {
    const dataString = formatarDataString(data);

    setTurnosPorData(prev =>
      prev.map(t => {
        if (t.data === dataString) {
          return { ...t, turnos: turnosOrdenados };
        }
        return t;
      })
    );

    // NÃO emitir evento - a ordem já está correta localmente
    // window.dispatchEvent(new CustomEvent('turnosAtualizados'));
  };

  return (
    <AdminContext.Provider
      value={{
        reservas,
        clientes,
        turnosPorData,
        adicionarReserva,
        atualizarReserva,
        excluirReserva,
        obterReservasPorCliente,
        adicionarCliente,
        atualizarCliente,
        excluirCliente,
        obterTurnosPorData,
        adicionarTurnoNaData,
        atualizarTurnoNaData,
        excluirTurnoNaData,
        ativarDesativarTurnoNaData,
        reordenarTurnosNaData,
        salvarOrdemTurnos,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
}