import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { db } from '../services/database';

export interface User {
  id: string;
  nomeCompleto: string;
  email: string;
  telefone: string;
  registroCRO: string;
  areaAtuacao: string;
  dataNascimento?: string;
  endereco?: string;
  fotoPerfil?: string;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, senha: string, lembrarDeMim: boolean) => Promise<void>;
  register: (userData: Omit<User, 'id'> & { senha: string }) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('vdc_current_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  // Inicializar banco de dados
  useEffect(() => {
    db.initialize();
  }, []);

  // Escutar atualizações do admin
  useEffect(() => {
    const handleClienteAtualizadoPorAdmin = (event: any) => {
      const { clienteId, dados } = event.detail;

      // Se o cliente atualizado for o user logado, atualizar
      if (user && user.id === clienteId) {
        // Recarregar dados completos do banco de dados
        const dbUser = db.getUserById(user.id);
        if (dbUser) {
          const updatedUser: User = {
            id: dbUser.id,
            nomeCompleto: dbUser.nomeCompleto,
            email: dbUser.email,
            telefone: dbUser.telefone,
            registroCRO: dbUser.registroCRO,
            areaAtuacao: dbUser.areaAtuacao,
            dataNascimento: dbUser.dataNascimento,
            endereco: dbUser.endereco,
            fotoPerfil: dbUser.fotoPerfil,
            isAdmin: dbUser.isAdmin,
          };
          setUser(updatedUser);
          localStorage.setItem('vdc_current_user', JSON.stringify(updatedUser));
        }
      }
    };

    window.addEventListener('clienteAtualizadoPorAdmin', handleClienteAtualizadoPorAdmin);
    return () => window.removeEventListener('clienteAtualizadoPorAdmin', handleClienteAtualizadoPorAdmin);
  }, [user]);

  const login = async (email: string, senha: string, lembrarDeMim: boolean) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    const dbUser = db.getUserByEmail(email);

    if (!dbUser || dbUser.senha !== senha) {
      throw new Error('Email ou senha inválidos');
    }

    const user: User = {
      id: dbUser.id,
      nomeCompleto: dbUser.nomeCompleto,
      email: dbUser.email,
      telefone: dbUser.telefone,
      registroCRO: dbUser.registroCRO,
      areaAtuacao: dbUser.areaAtuacao,
      dataNascimento: dbUser.dataNascimento,
      endereco: dbUser.endereco,
      fotoPerfil: dbUser.fotoPerfil,
      isAdmin: dbUser.isAdmin,
    };

    setUser(user);
    localStorage.setItem('vdc_current_user', JSON.stringify(user));

    // Disparar evento de login para sincronizar outros contextos
    window.dispatchEvent(new CustomEvent('userLoggedIn', { detail: { userId: user.id } }));
  };

  const register = async (userData: Omit<User, 'id'> & { senha: string }) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    // Verificar se email já existe
    if (db.getUserByEmail(userData.email)) {
      throw new Error('Email já cadastrado');
    }

    const dbUser = db.createUser({
      nomeCompleto: userData.nomeCompleto,
      email: userData.email,
      senha: userData.senha,
      telefone: userData.telefone,
      registroCRO: userData.registroCRO,
      areaAtuacao: userData.areaAtuacao,
      dataNascimento: userData.dataNascimento,
      endereco: userData.endereco,
      fotoPerfil: userData.fotoPerfil,
    });

    const newUser: User = {
      id: dbUser.id,
      nomeCompleto: dbUser.nomeCompleto,
      email: dbUser.email,
      telefone: dbUser.telefone,
      registroCRO: dbUser.registroCRO,
      areaAtuacao: dbUser.areaAtuacao,
      dataNascimento: dbUser.dataNascimento,
      endereco: dbUser.endereco,
      fotoPerfil: dbUser.fotoPerfil,
    };

    setUser(newUser);
    localStorage.setItem('vdc_current_user', JSON.stringify(newUser));

    // Notificar AdminContext sobre novo cliente
    window.dispatchEvent(
      new CustomEvent('novoCliente', {
        detail: { cliente: newUser },
      })
    );
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('vdc_current_user');
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      // Atualizar no banco de dados
      db.updateUser(user.id, {
        telefone: userData.telefone,
        email: userData.email,
        areaAtuacao: userData.areaAtuacao,
        dataNascimento: userData.dataNascimento,
        endereco: userData.endereco,
        fotoPerfil: userData.fotoPerfil,
      });

      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      localStorage.setItem('vdc_current_user', JSON.stringify(updatedUser));

      // Notificar AdminContext sobre atualização
      window.dispatchEvent(new Event('clienteAtualizado'));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
