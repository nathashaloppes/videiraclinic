import { createContext, useContext, useState, ReactNode, useEffect, useCallback } from 'react';
import { db } from '../services/database';
import { format } from 'date-fns';

export interface Turno {
  id: string;
  nome: string;
  horario: string;
  preco: number;
}

export interface TransacaoCredito {
  reservaId: string;
  userId: string;
  valor: number;
  tipo: 'debito' | 'credito';
  data: Date;
  descricao: string;
}

export interface Reserva {
  id: string;
  userId: string;
  data: Date;
  turnos: Turno[];
  total: number;
  status: 'pendente' | 'confirmada' | 'cancelada';
  dataCriacao: Date;
  creditoUtilizado?: number;
}

interface ReservasContextType {
  turnos: Turno[];
  turnosSelecionados: { data: Date; turnos: Turno[] }[];
  reservas: Reserva[];
  turnosDisponiveis: (data: Date) => Turno[];
  selecionarTurno: (data: Date, turno: Turno) => void;
  removerTurno: (data: Date, turnoId: string) => void;
  limparSelecao: () => void;
  criarReserva: (userId: string, user?: any, creditoUtilizado?: number) => Promise<Reserva>;
  obterReservasPorMes: (mes: number, ano: number) => Reserva[];
  registrarTransacaoCredito: (transacao: Omit<TransacaoCredito, 'data'>) => void;
}

const ReservasContext = createContext<ReservasContextType | undefined>(undefined);

export function ReservasProvider({ children }: { children: ReactNode }) {
  const [turnosSelecionados, setTurnosSelecionados] = useState<{ data: Date; turnos: Turno[] }[]>([]);
  const [reservas, setReservas] = useState<Reserva[]>([]);

  // Função para carregar reservas do banco de dados
  const carregarReservas = useCallback(() => {
    const currentUserId = localStorage.getItem('vdc_current_user') ? JSON.parse(localStorage.getItem('vdc_current_user')!).id : null;

    if (currentUserId) {
      const dbReservas = db.getReservasByUserId(currentUserId);
      const reservasCarregadas = dbReservas.map(r => {
        const novaReserva: Reserva = {
          id: r.id,
          userId: r.userId,
          data: new Date(r.data + 'T00:00:00'),
          turnos: [{
            id: r.id,
            nome: r.periodo,
            horario: `${r.inicio.replace(':', 'h')} às ${r.fim.replace(':', 'h')}`,
            preco: r.valor,
          }],
          total: r.valor,
          status: r.status as 'confirmada' | 'cancelada',
          dataCriacao: new Date(r.createdAt),
          creditoUtilizado: r.creditoUtilizado || 0,
        };
        return novaReserva;
      }).filter(r => r.status === 'confirmada');

      setReservas(reservasCarregadas);
    }
  }, []);

  // Carregar reservas do banco de dados ao montar
  useEffect(() => {
    carregarReservas();
  }, [carregarReservas]);

  // Escutar evento de login para recarregar reservas
  useEffect(() => {
    const handleUserLoggedIn = () => {
      carregarReservas();
    };

    window.addEventListener('userLoggedIn', handleUserLoggedIn);
    return () => window.removeEventListener('userLoggedIn', handleUserLoggedIn);
  }, [carregarReservas]);

  // Sincronizar reservas do AdminContext
  useEffect(() => {
    const handleReservaAdmin = () => {
      carregarReservas();
    };

    const handleReservaCriada = (event: any) => {
      const { userId } = event.detail;
      const currentUserId = localStorage.getItem('vdc_current_user') ? JSON.parse(localStorage.getItem('vdc_current_user')!).id : null;

      if (userId === currentUserId) {
        carregarReservas();
      }
    };

    const handleReservaAtualizada = () => {
      carregarReservas();
    };

    const handleReservaCancelada = () => {
      carregarReservas();
    };

    window.addEventListener('turnosAtualizados', handleReservaAdmin);
    window.addEventListener('reservaCriada', handleReservaCriada);
    window.addEventListener('reservaAtualizada', handleReservaAtualizada);
    window.addEventListener('reservaCancelada', handleReservaCancelada);

    return () => {
      window.removeEventListener('turnosAtualizados', handleReservaAdmin);
      window.removeEventListener('reservaCriada', handleReservaCriada);
      window.removeEventListener('reservaAtualizada', handleReservaAtualizada);
      window.removeEventListener('reservaCancelada', handleReservaCancelada);
    };
  }, [carregarReservas]);

  const turnosDisponiveisParaData = (data: Date): Turno[] => {
    // Obter turnos configurados pelo admin para esta data
    const turnosPorData = (window as any).__turnosPorData || [];
    const dataString = `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, '0')}-${String(data.getDate()).padStart(2, '0')}`;

    const turnosDaData = turnosPorData.find((t: any) => t.data === dataString);
    if (!turnosDaData) {
      return []; // Sem turnos configurados para esta data
    }

    // Filtrar apenas turnos ativos
    const turnosAtivos = turnosDaData.turnos.filter((t: any) => t.ativo);

    // Obter todas as reservas confirmadas para esta data (de todos os usuários)
    const reservasNaData = reservas.filter(
      r => r.data.toDateString() === data.toDateString() && r.status === 'confirmada'
    );

    const turnosReservados = reservasNaData.flatMap(r => r.turnos.map(t => t.id));

    // Retornar apenas turnos que não foram reservados
    return turnosAtivos
      .filter((t: any) => !turnosReservados.includes(t.id))
      .map((t: any) => ({
        id: t.id,
        nome: t.periodo,
        horario: `${t.inicio.replace(':', 'h')} às ${t.fim.replace(':', 'h')}`,
        preco: t.valor,
      }));
  };

  const selecionarTurno = (data: Date, turno: Turno) => {
    setTurnosSelecionados(prev => {
      const existingDate = prev.find(
        item => item.data.toDateString() === data.toDateString()
      );

      if (existingDate) {
        const turnoJaSelecionado = existingDate.turnos.find(t => t.id === turno.id);

        if (turnoJaSelecionado) {
          // Remove o turno se já estiver selecionado
          return prev.map(item =>
            item.data.toDateString() === data.toDateString()
              ? { ...item, turnos: item.turnos.filter(t => t.id !== turno.id) }
              : item
          ).filter(item => item.turnos.length > 0);
        } else {
          // Adiciona o turno
          return prev.map(item =>
            item.data.toDateString() === data.toDateString()
              ? { ...item, turnos: [...item.turnos, turno] }
              : item
          );
        }
      } else {
        return [...prev, { data, turnos: [turno] }];
      }
    });
  };

  const removerTurno = (data: Date, turnoId: string) => {
    setTurnosSelecionados(prev =>
      prev.map(item =>
        item.data.toDateString() === data.toDateString()
          ? { ...item, turnos: item.turnos.filter(t => t.id !== turnoId) }
          : item
      ).filter(item => item.turnos.length > 0)
    );
  };

  const limparSelecao = () => {
    setTurnosSelecionados([]);
  };

  const criarReserva = async (userId: string, user?: any, creditoUtilizado?: number): Promise<Reserva> => {
    await new Promise(resolve => setTimeout(resolve, 500));

    const reservasCriadas: Reserva[] = [];

    for (const item of turnosSelecionados) {
      const total = item.turnos.reduce((sum, t) => sum + t.preco, 0);

      for (const turno of item.turnos) {
        const inicio = turno.horario.split(' às ')[0].replace('h', ':');
        const fim = turno.horario.split(' às ')[1].replace('h', ':');
        const dataFormatada = format(item.data, 'yyyy-MM-dd');

        // Salvar no banco de dados
        const dbReserva = db.createReserva({
          userId,
          data: dataFormatada,
          inicio,
          fim,
          periodo: turno.nome,
          valor: turno.preco,
          status: 'confirmada',
          creditoUtilizado: creditoUtilizado || 0,
        });

        // Marcar turnos como reservados
        db.marcarTurnosComoReservados(dataFormatada, inicio, fim);

        const reserva: Reserva = {
          id: dbReserva.id,
          userId,
          data: item.data,
          turnos: [turno],
          total: turno.preco,
          status: 'confirmada',
          dataCriacao: new Date(dbReserva.createdAt),
          creditoUtilizado: creditoUtilizado || 0,
        };

        reservasCriadas.push(reserva);
      }
    }

    // Registrar transação de crédito se foi utilizado
    if (creditoUtilizado && creditoUtilizado > 0) {
      db.debitarCredito(
        userId,
        creditoUtilizado,
        'Pagamento de reserva com créditos',
        reservasCriadas[0]?.id
      );
    }

    // Atualizar estado local
    setReservas(prev => [...prev, ...reservasCriadas]);

    // Emitir evento para sincronizar
    window.dispatchEvent(new CustomEvent('novaReserva', {
      detail: { reservas: reservasCriadas, userId, user }
    }));

    setTurnosSelecionados([]);

    return reservasCriadas[0];
  };

  const registrarTransacaoCredito = (transacao: Omit<TransacaoCredito, 'data'>) => {
    db.createTransacao(transacao);
  };

  const obterReservasPorMes = (mes: number, ano: number): Reserva[] => {
    const userId = localStorage.getItem('vdc_current_user') ? JSON.parse(localStorage.getItem('vdc_current_user')!).id : null;
    if (!userId) return [];

    // Buscar todas as reservas do usuário do banco de dados
    const dbReservas = db.getReservasByUserId(userId);

    // Converter para o formato esperado
    const reservasFormatadas = dbReservas.map(r => {
      const data = new Date(r.data + 'T00:00:00');
      return {
        id: r.id,
        userId: r.userId,
        data,
        turnos: [{
          id: r.id,
          nome: r.periodo,
          horario: `${r.inicio.replace(':', 'h')} às ${r.fim.replace(':', 'h')}`,
          preco: r.valor,
        }],
        total: r.valor,
        status: r.status as 'confirmada' | 'cancelada',
        dataCriacao: new Date(r.createdAt),
        creditoUtilizado: r.creditoUtilizado,
      };
    });

    // Filtrar por mês e ano
    return reservasFormatadas.filter(r => {
      return r.data.getMonth() === mes && r.data.getFullYear() === ano && r.status === 'confirmada';
    });
  };

  return (
    <ReservasContext.Provider
      value={{
        turnos: [],
        turnosSelecionados,
        reservas,
        turnosDisponiveis: turnosDisponiveisParaData,
        selecionarTurno,
        removerTurno,
        limparSelecao,
        criarReserva,
        obterReservasPorMes,
        registrarTransacaoCredito,
      }}
    >
      {children}
    </ReservasContext.Provider>
  );
}

export function useReservas() {
  const context = useContext(ReservasContext);
  if (context === undefined) {
    throw new Error('useReservas must be used within a ReservasProvider');
  }
  return context;
}