import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { useReservas } from '../contexts/ReservasContext';

export function Cadastro() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const { turnosSelecionados } = useReservas();

  const [nomeCompleto, setNomeCompleto] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [telefone, setTelefone] = useState('');
  const [registroCRO, setRegistroCRO] = useState('');
  const [areaAtuacao, setAreaAtuacao] = useState('');
  const [aceitouTermos, setAceitouTermos] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (senha !== confirmarSenha) {
      alert('As senhas não coincidem');
      return;
    }

    if (!aceitouTermos) {
      alert('Você precisa aceitar os Termos de Uso e Política de Privacidade');
      return;
    }

    setIsLoading(true);

    try {
      await register({
        nomeCompleto,
        email,
        telefone,
        registroCRO,
        areaAtuacao,
        senha
      });
      navigate('/');
    } catch (error) {
      console.error('Erro ao criar conta:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatTelefone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return numbers.replace(/(\d{2})(\d+)/, '($1)$2');
    if (numbers.length <= 11) return numbers.replace(/(\d{2})(\d{5})(\d+)/, '($1)$2-$3');
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1)$2-$3');
  };

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
      <div className="max-w-md mx-auto px-4 py-6">
        <button
          onClick={() => navigate('/login')}
          className="mb-8 p-2 hover:bg-white/50 rounded-full"
        >
          <ChevronLeft className="w-6 h-6" style={{ color: '#5D4037' }} />
        </button>

        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-2xl mb-8"
          style={{ color: '#5D4037' }}
        >
          Entrar
        </motion.h1>

        {turnosSelecionados.length > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6 rounded-r-2xl"
          >
            <p className="text-sm" style={{ color: '#5D4037' }}>
              Após fazer seu login, você voltará para a tela de reservas com o turno que selecionou.
            </p>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-6 shadow-lg"
        >
          <div className="flex gap-4 mb-8 border-b" style={{ borderColor: '#E0E0E0' }}>
            <button
              onClick={() => navigate('/login')}
              className="pb-3 px-1 text-gray-400"
            >
              Entrar
            </button>
            <button
              className="pb-3 px-1 border-b-2 transition-colors"
              style={{ borderColor: '#5D4037', color: '#5D4037' }}
            >
              Criar conta
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="text"
                placeholder="Nome completo*"
                value={nomeCompleto}
                onChange={(e) => setNomeCompleto(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="email"
                placeholder="E-mail*"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="password"
                placeholder="Senha*"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="password"
                placeholder="Confirmar senha*"
                value={confirmarSenha}
                onChange={(e) => setConfirmarSenha(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="tel"
                placeholder="Número de telefone*"
                value={telefone}
                onChange={(e) => setTelefone(formatTelefone(e.target.value))}
                required
                autoComplete="tel"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="text"
                placeholder="Registro CRO*"
                value={registroCRO}
                onChange={(e) => setRegistroCRO(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <input
                type="text"
                placeholder="Área de atuação*"
                value={areaAtuacao}
                onChange={(e) => setAreaAtuacao(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <label className="flex items-start gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={aceitouTermos}
                onChange={(e) => setAceitouTermos(e.target.checked)}
                className="w-4 h-4 mt-1 rounded"
                style={{ accentColor: '#5D4037' }}
              />
              <span className="text-sm" style={{ color: '#3E2723' }}>
                Li e aceito os Termos de Uso e a Política de Privacidade.
              </span>
            </label>

            <button
              type="submit"
              disabled={isLoading || !aceitouTermos}
              className="w-full py-3 rounded-full text-white disabled:opacity-50"
              style={{
                backgroundColor: aceitouTermos ? '#5D4037' : '#BDBDBD',
              }}
            >
              {isLoading ? 'Criando conta...' : 'Criar conta'}
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}