import { useState } from 'react';
import { useNavigate } from 'react-router';
import { X, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useReservas } from '../contexts/ReservasContext';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function ConfirmarReserva() {
  const navigate = useNavigate();
  const { turnosSelecionados, removerTurno } = useReservas();

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [turnoToDelete, setTurnoToDelete] = useState<{
    data: Date;
    turnoId: string;
  } | null>(null);

  const allTurnos = turnosSelecionados.flatMap((item) =>
    item.turnos.map((turno) => ({
      ...turno,
      data: item.data,
    }))
  );

  const total = allTurnos.reduce((sum, turno) => sum + (turno.preco / 100), 0);

  const handleDeleteClick = (data: Date, turnoId: string) => {
    setTurnoToDelete({ data, turnoId });
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = () => {
    if (turnoToDelete) {
      removerTurno(turnoToDelete.data, turnoToDelete.turnoId);
      setShowDeleteModal(false);
      setTurnoToDelete(null);

      if (turnosSelecionados.length === 0 ||
          (turnosSelecionados.length === 1 &&
           turnosSelecionados[0].turnos.length === 1)) {
        navigate('/');
      }
    }
  };

  const handleConfirmarReserva = () => {
    navigate('/pagamento');
  };

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: 'rgba(0, 0, 0, 0.3)' }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-3xl p-6 shadow-2xl w-[90vw] max-w-md max-h-[80vh] overflow-y-auto"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#fef8e1' }}>
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#5D4037"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
              <line x1="16" y1="2" x2="16" y2="6" />
              <line x1="8" y1="2" x2="8" y2="6" />
              <line x1="3" y1="10" x2="21" y2="10" />
            </svg>
          </div>
          <h2 className="text-lg flex-1" style={{ color: '#5D4037' }}>
            Confirmar reserva
          </h2>
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <X className="w-5 h-5" style={{ color: '#8D6E63' }} />
          </button>
        </div>

        <div className="space-y-3 mb-6">
          {allTurnos.map((turno) => (
            <div
              key={`${turno.data.toISOString()}_${turno.id}`}
              className="flex items-center justify-between px-4 py-3 rounded-full"
              style={{ backgroundColor: '#fef8e1' }}
            >
              <div className="flex-1">
                <div className="text-sm" style={{ color: '#3E2723' }}>
                  {format(turno.data, "dd/MM")} •{' '}
                  {turno.nome.toLowerCase()} • R${(turno.preco / 100).toFixed(2)}
                </div>
              </div>
              <button
                onClick={() => handleDeleteClick(turno.data, turno.id)}
                className="p-2 rounded-full hover:bg-white/50"
              >
                <Trash2 className="w-4 h-4" style={{ color: '#8D6E63' }} />
              </button>
            </div>
          ))}
        </div>

        <div className="border-t pt-4 mb-6" style={{ borderColor: '#E0E0E0' }}>
          <div className="flex justify-between items-center">
            <span className="text-sm" style={{ color: '#8D6E63' }}>
              Total
            </span>
            <span className="text-xl" style={{ color: '#5D4037' }}>
              R$ {total.toFixed(2).replace('.', ',')}
            </span>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => navigate('/')}
            className="flex-1 py-3 rounded-full border-2"
            style={{ borderColor: '#5D4037', color: '#5D4037' }}
          >
            Cancelar
          </button>
          <button
            onClick={handleConfirmarReserva}
            className="flex-1 py-3 rounded-full text-white"
            style={{ backgroundColor: '#5D4037' }}
          >
            Confirmar reserva
          </button>
        </div>
      </motion.div>

      <AnimatePresence>
        {showDeleteModal && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[60] bg-white rounded-3xl p-8 shadow-2xl w-[85vw] max-w-sm"
          >
            <h3 className="text-lg mb-6 text-center" style={{ color: '#5D4037' }}>
              Tem certeza que deseja excluir um item?
            </h3>

            <div className="flex gap-4">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 py-3 rounded-full border-2"
                style={{ borderColor: '#5D4037', color: '#5D4037' }}
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmDelete}
                className="flex-1 py-3 rounded-full text-white"
                style={{ backgroundColor: '#5D4037' }}
              >
                Excluir
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}