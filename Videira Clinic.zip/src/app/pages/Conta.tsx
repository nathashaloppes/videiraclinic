import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Logo } from '../components/Logo';
import { Avatar } from '../components/Avatar';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { db } from '../services/database';

export function Conta() {
  const navigate = useNavigate();
  const { user, logout, updateUser } = useAuth();
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  
  // Estados para edição
  const [nomeCompleto, setNomeCompleto] = useState(user?.nomeCompleto || '');
  const [dataNascimento, setDataNascimento] = useState(user?.dataNascimento || '01/01/2001');
  const [telefone, setTelefone] = useState(user?.telefone || '');
  const [email, setEmail] = useState(user?.email || '');
  const [registroCRO, setRegistroCRO] = useState(user?.registroCRO || '');
  const [areaAtuacao, setAreaAtuacao] = useState(user?.areaAtuacao || '');
  
  // Estados para endereço separado
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [cep, setCep] = useState('');

  // Carregar dados do banco de dados ao montar o componente
  useEffect(() => {
    if (user) {
      const dbUser = db.getUserById(user.id);
      if (dbUser && dbUser.endereco) {
        // Parsear endereço salvo
        // Formato esperado: "Rua X, 123, Complemento, Bairro, Cidade - UF, CEP"
        const partes = dbUser.endereco.split(', ');

        if (partes.length > 0) {
          // Primeira parte pode ser "Rua X, 123" ou apenas "Rua X"
          const primeiraParte = partes[0];
          const ultimoEspaco = primeiraParte.lastIndexOf(' ');

          if (ultimoEspaco > 0) {
            const possivelNumero = primeiraParte.substring(ultimoEspaco + 1);
            // Verificar se é um número
            if (!isNaN(Number(possivelNumero))) {
              setRua(primeiraParte.substring(0, ultimoEspaco));
              setNumero(possivelNumero);
            } else {
              setRua(primeiraParte);
            }
          } else {
            setRua(primeiraParte);
          }
        }

        if (partes.length > 1) setComplemento(partes[1]);
        if (partes.length > 2) setBairro(partes[2]);

        if (partes.length > 3) {
          const cidadeEstado = partes[3].split(' - ');
          setCidade(cidadeEstado[0] || '');
          setEstado(cidadeEstado[1] || '');
        }

        if (partes.length > 4) setCep(partes[4]);
      }
    }
  }, [user]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleSaveProfile = () => {
    // Montar endereço completo
    const enderecoCompleto = [
      rua && numero ? `${rua}, ${numero}` : rua || numero,
      complemento,
      bairro,
      `${cidade} - ${estado}`,
      cep
    ].filter(Boolean).join(', ');

    // Atualizar dados do usuário (Nome completo e registroCRO não podem ser alterados)
    updateUser({
      dataNascimento,
      telefone,
      email,
      areaAtuacao,
      endereco: enderecoCompleto
    });

    toast.success('Dados salvos com sucesso!');
  };

  const formatTelefone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return numbers.replace(/(\d{2})(\d+)/, '($1)$2');
    if (numbers.length <= 11) return numbers.replace(/(\d{2})(\d{5})(\d+)/, '($1)$2-$3');
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1)$2-$3');
  };

  const formatDataNascimento = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 4) return numbers.replace(/(\d{2})(\d+)/, '$1/$2');
    return numbers.replace(/(\d{2})(\d{2})(\d+)/, '$1/$2/$3').substring(0, 10);
  };

  const formatCEP = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 5) return numbers;
    return numbers.replace(/(\d{5})(\d+)/, '$1-$2').substring(0, 9);
  };

  const handleCEPChange = async (value: string) => {
    const formatted = formatCEP(value);
    setCep(formatted);

    // Se CEP estiver completo, buscar endereço
    const numbers = formatted.replace(/\D/g, '');
    if (numbers.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${numbers}/json/`);
        const data = await response.json();
        
        if (!data.erro) {
          setRua(data.logradouro || '');
          setBairro(data.bairro || '');
          setCidade(data.localidade || '');
          setEstado(data.uf || '');
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
      <div className="max-w-md mx-auto px-4 py-6">
        <button
          onClick={() => navigate('/')}
          className="mb-2 p-2 hover:bg-white/50 rounded-full"
        >
          <ChevronLeft className="w-6 h-6" style={{ color: '#5D4037' }} />
        </button>

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center mb-8"
        >
          <Logo />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-6 shadow-lg mb-4"
        >
          <div className="flex flex-col items-center mb-8">
            <Avatar user={user} size="lg" />
            <button className="mt-2 text-sm hover:underline" style={{ color: '#8D6E63' }}>
              Adicionar foto
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                Nome completo
              </label>
              <input
                type="text"
                value={nomeCompleto}
                disabled
                autoComplete="name"
                className="w-full px-4 py-3 rounded-2xl border text-sm bg-gray-50 cursor-not-allowed"
                style={{ borderColor: '#E0E0E0', color: '#9E9E9E' }}
              />
            </div>

            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                Registro CRO
              </label>
              <input
                type="text"
                value={registroCRO}
                disabled
                className="w-full px-4 py-3 rounded-2xl border text-sm bg-gray-50 cursor-not-allowed"
                style={{ borderColor: '#E0E0E0', color: '#9E9E9E' }}
              />
            </div>

            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                Área de atuação
              </label>
              <input
                type="text"
                value={areaAtuacao}
                onChange={(e) => setAreaAtuacao(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                  Data de nascimento
                </label>
                <input
                  type="text"
                  value={dataNascimento}
                  onChange={(e) => setDataNascimento(formatDataNascimento(e.target.value))}
                  placeholder="dd/mm/aaaa"
                  autoComplete="bday"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <div>
                <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                  Contato
                </label>
                <input
                  type="tel"
                  value={telefone}
                  onChange={(e) => setTelefone(formatTelefone(e.target.value))}
                  placeholder="(00)00000-0000"
                  autoComplete="tel"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                E-mail
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                CEP
              </label>
              <input
                type="text"
                value={cep}
                onChange={(e) => handleCEPChange(e.target.value)}
                placeholder="00000-000"
                autoComplete="postal-code"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2">
                <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                  Rua
                </label>
                <input
                  type="text"
                  value={rua}
                  onChange={(e) => setRua(e.target.value)}
                  autoComplete="address-line1"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <div>
                <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                  Número
                </label>
                <input
                  type="text"
                  value={numero}
                  onChange={(e) => setNumero(e.target.value)}
                  autoComplete="off"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                Complemento
              </label>
              <input
                type="text"
                value={complemento}
                onChange={(e) => setComplemento(e.target.value)}
                autoComplete="address-line2"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div>
              <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                Bairro
              </label>
              <input
                type="text"
                value={bairro}
                onChange={(e) => setBairro(e.target.value)}
                autoComplete="off"
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2">
                <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                  Cidade
                </label>
                <input
                  type="text"
                  value={cidade}
                  onChange={(e) => setCidade(e.target.value)}
                  autoComplete="address-level2"
                  className="w-full px-4 py-3 rounded-2xl border text-sm"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>

              <div>
                <label className="block text-sm mb-1" style={{ color: '#8D6E63' }}>
                  Estado
                </label>
                <input
                  type="text"
                  value={estado}
                  onChange={(e) => setEstado(e.target.value.toUpperCase().substring(0, 2))}
                  placeholder="UF"
                  maxLength={2}
                  autoComplete="address-level1"
                  className="w-full px-4 py-3 rounded-2xl border text-sm uppercase"
                  style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                />
              </div>
            </div>

            <button
              onClick={handleSaveProfile}
              className="w-full py-3 rounded-full text-white"
              style={{ backgroundColor: '#5D4037' }}
            >
              Salvar alterações
            </button>
          </div>
        </motion.div>

        <button
          onClick={() => setShowLogoutModal(true)}
          className="w-full py-3 rounded-full border-2 flex items-center justify-center gap-2"
          style={{ borderColor: '#D32F2F', color: '#D32F2F' }}
        >
          <LogOut className="w-4 h-4" />
          Sair da conta
        </button>
      </div>

      <AnimatePresence>
        {showLogoutModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/30 z-40"
              onClick={() => setShowLogoutModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white rounded-3xl p-8 shadow-2xl w-[90vw] max-w-sm"
            >
              <h3 className="text-lg mb-6 text-center" style={{ color: '#5D4037' }}>
                Tem certeza que deseja sair?
              </h3>

              <div className="flex gap-4">
                <button
                  onClick={() => setShowLogoutModal(false)}
                  className="flex-1 py-3 rounded-full border-2"
                  style={{ borderColor: '#5D4037', color: '#5D4037' }}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleLogout}
                  className="flex-1 py-3 rounded-full text-white"
                  style={{ backgroundColor: '#5D4037' }}
                >
                  Sair
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}