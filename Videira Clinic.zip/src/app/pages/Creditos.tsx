import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Wallet, Plus, X } from 'lucide-react';
import { motion } from 'motion/react';
import { Logo } from '../components/Logo';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { db } from '../services/database';

export function Creditos() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [creditos, setCreditos] = useState(0);
  const [modalAdicionarCredito, setModalAdicionarCredito] = useState(false);
  const [valor, setValor] = useState('');
  const [showQRCode, setShowQRCode] = useState(false);

  useEffect(() => {
    if (user) {
      const creditosArmazenados = db.getCredito(user.id);
      setCreditos(creditosArmazenados);
    }

    // Listener para atualizar créditos quando houver mudanças
    const handleCreditoAtualizado = () => {
      if (user) {
        setCreditos(db.getCredito(user.id));
      }
    };

    window.addEventListener('creditoAtualizado', handleCreditoAtualizado);
    return () => window.removeEventListener('creditoAtualizado', handleCreditoAtualizado);
  }, [user]);

  const formatValor = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const numberValue = parseFloat(numbers) / 100;
    return numberValue.toFixed(2).replace('.', ',');
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatValor(e.target.value);
    setValor(formatted);
  };

  const parseValor = (formatted: string): number => {
    const numbers = formatted.replace(/\D/g, '');
    if (!numbers) return 0;
    return parseFloat(numbers);
  };

  const handleAdicionarCredito = () => {
    const valorNumerico = parseValor(valor);
    if (valorNumerico > 0) {
      setShowQRCode(true);
    } else {
      toast.error('Digite um valor válido');
    }
  };

  const handleConfirmarPagamento = () => {
    const valorNumerico = parseValor(valor);
    if (user) {
      db.adicionarCredito(user.id, valorNumerico, 'Crédito adicionado via PIX');
      setCreditos(db.getCredito(user.id));
      setShowQRCode(false);
      setModalAdicionarCredito(false);
      setValor('');
      toast.success('Crédito adicionado com sucesso!');
      window.dispatchEvent(new Event('creditoAtualizado'));
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
      <div className="max-w-md mx-auto px-4 py-6">
        <button
          onClick={() => navigate('/')}
          className="mb-2 p-2 hover:bg-white/50 rounded-full"
        >
          <ChevronLeft className="w-6 h-6" style={{ color: '#5D4037' }} />
        </button>

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center mb-8"
        >
          <Logo />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h2 className="text-xl mb-6" style={{ color: '#5D4037' }}>
            Meus Créditos
          </h2>

          {/* Saldo de Créditos */}
          <div className="bg-white rounded-3xl p-8 shadow-lg mb-6 text-center">
            <Wallet className="w-12 h-12 mx-auto mb-4" style={{ color: '#8D6E63' }} />
            <p className="text-sm mb-2" style={{ color: '#8D6E63' }}>
              Saldo disponível
            </p>
            <p className="text-3xl font-bold" style={{ color: '#5D4037' }}>
              R$ {(creditos / 100).toFixed(2).replace('.', ',')}
            </p>
          </div>

          {/* Botão Adicionar Crédito */}
          <button
            onClick={() => setModalAdicionarCredito(true)}
            className="w-full bg-white rounded-3xl p-6 shadow-lg flex items-center justify-between hover:shadow-xl transition-shadow"
          >
            <div className="flex items-center gap-4">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#D7CCC8' }}
              >
                <Plus className="w-6 h-6" style={{ color: '#5D4037' }} />
              </div>
              <div className="text-left">
                <p style={{ color: '#3E2723' }}>Adicionar crédito</p>
                <p className="text-sm" style={{ color: '#8D6E63' }}>
                  Adicione saldo via PIX
                </p>
              </div>
            </div>
          </button>

          {/* Informação */}
          <div className="bg-white rounded-3xl p-6 shadow-lg mt-6">
            <p className="text-sm" style={{ color: '#8D6E63' }}>
              Seus créditos podem ser utilizados para reservar turnos. Quando você altera uma reserva para um turno mais barato, a diferença é adicionada aos seus créditos automaticamente.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Modal Adicionar Crédito */}
      {modalAdicionarCredito && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg" style={{ color: '#5D4037' }}>
                Adicionar Crédito
              </h2>
              <button
                onClick={() => {
                  setModalAdicionarCredito(false);
                  setShowQRCode(false);
                  setValor('');
                }}
                className="p-1 hover:bg-gray-100 rounded-full"
              >
                <X className="w-5 h-5" style={{ color: '#5D4037' }} />
              </button>
            </div>

            {!showQRCode ? (
              <>
                <div className="mb-6">
                  <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                    Valor
                  </label>
                  <input
                    type="text"
                    placeholder="R$ 0,00"
                    value={`R$ ${valor}`}
                    onChange={handleValorChange}
                    className="w-full px-4 py-3 rounded-2xl border text-sm"
                    style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                    autoFocus
                  />
                </div>

                <button
                  onClick={handleAdicionarCredito}
                  className="w-full py-3 rounded-full text-white"
                  style={{ backgroundColor: '#5D4037' }}
                >
                  Gerar PIX
                </button>
              </>
            ) : (
              <>
                <div className="bg-gray-100 rounded-2xl p-8 mb-6 text-center">
                  <div
                    className="w-48 h-48 mx-auto bg-white rounded-xl flex items-center justify-center mb-4"
                    style={{ borderWidth: 2, borderColor: '#E0E0E0' }}
                  >
                    <p className="text-xs text-gray-400">QR Code PIX</p>
                  </div>
                  <p className="text-sm mb-2" style={{ color: '#3E2723' }}>
                    Escaneie o QR Code para pagar
                  </p>
                  <p className="text-lg font-bold" style={{ color: '#5D4037' }}>
                    R$ {valor}
                  </p>
                </div>

                <button
                  onClick={handleConfirmarPagamento}
                  className="w-full py-3 rounded-full text-white mb-2"
                  style={{ backgroundColor: '#5D4037' }}
                >
                  Simular Pagamento
                </button>

                <button
                  onClick={() => {
                    setShowQRCode(false);
                    setValor('');
                  }}
                  className="w-full py-3 rounded-full border-2"
                  style={{ borderColor: '#5D4037', color: '#5D4037' }}
                >
                  Cancelar
                </button>
              </>
            )}
          </motion.div>
        </div>
      )}
    </div>
  );
}