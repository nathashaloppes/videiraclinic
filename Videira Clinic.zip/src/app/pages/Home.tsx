import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, CalendarDays, Wallet } from 'lucide-react';
import { motion } from 'motion/react';
import { Logo } from '../components/Logo';
import { Avatar } from '../components/Avatar';
import { CalendarioModal } from '../components/CalendarioModal';
import { useAuth } from '../contexts/AuthContext';
import { useReservas } from '../contexts/ReservasContext';
import { format, addDays, startOfWeek, differenceInDays, addMonths, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function Home() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { turnosSelecionados, turnosDisponiveis, selecionarTurno, limparSelecao } = useReservas();

  const [selectedDate, setSelectedDate] = useState(() => addDays(startOfDay(new Date()), 1));
  const [weekDates, setWeekDates] = useState<Date[]>([]);
  const [weekStartIndex, setWeekStartIndex] = useState(0);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  useEffect(() => {
    // Gerar datas começando de amanhã (1 dia de antecedência) até 3 meses à frente
    const today = startOfDay(new Date());
    const tomorrow = addDays(today, 1); // Começar de amanhã
    const maxDate = addMonths(tomorrow, 3);

    // Calcular quantos dias precisamos até o maxDate
    const totalDays = differenceInDays(maxDate, tomorrow) + 1;

    // Gerar array de datas começando de amanhã
    const dates = Array.from({ length: totalDays }, (_, i) => addDays(tomorrow, i));
    setWeekDates(dates);

    // Começar da primeira semana (índice 0)
    setWeekStartIndex(0);
  }, []);

  const visibleDates = weekDates.slice(weekStartIndex, weekStartIndex + 7);

  const availableTurnos = turnosDisponiveis(selectedDate);
  const selectedTurnosForDate =
    turnosSelecionados.find(
      item => item.data.toDateString() === selectedDate.toDateString()
    )?.turnos || [];

  const totalTurnosSelecionados = turnosSelecionados.reduce(
    (sum, item) => sum + item.turnos.length,
    0
  );

  const handleAvatarClick = () => {
    if (isAuthenticated) {
      navigate('/conta');
    } else {
      navigate('/login');
    }
  };

  const handleMinhasReservasClick = () => {
    navigate('/minhas-reservas');
  };

  const updateWeekForDate = (date: Date) => {
    if (weekDates.length === 0) return;
    const today = startOfDay(new Date());
    const daysSinceToday = differenceInDays(date, today);
    const newWeekIndex = Math.max(0, Math.floor(daysSinceToday / 7) * 7);
    if (newWeekIndex < weekDates.length) {
      setWeekStartIndex(newWeekIndex);
    }
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    updateWeekForDate(date);
  };

  const handleNextWeek = () => {
    if (weekStartIndex + 7 < weekDates.length) {
      setWeekStartIndex(weekStartIndex + 7);
    }
  };

  const handlePrevWeek = () => {
    if (weekStartIndex - 7 >= 0) {
      setWeekStartIndex(weekStartIndex - 7);
    }
  };

  const handleTurnoClick = (turno: typeof availableTurnos[0]) => {
    selecionarTurno(selectedDate, turno);
  };

  const isTurnoSelected = (turnoId: string) => {
    return selectedTurnosForDate.some(t => t.id === turnoId);
  };

  const handleReservarClick = () => {
    if (!isAuthenticated) {
      navigate('/login');
    } else {
      navigate('/confirmar-reserva');
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
      <div className="max-w-md mx-auto px-4 py-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center mb-8 relative"
        >
          <Logo />
          <div className="absolute right-0 top-0 flex items-center gap-3">
            {isAuthenticated && (
              <>
                <button onClick={() => navigate('/creditos')}>
                  <Wallet className="w-6 h-6" style={{ color: '#5D4037' }} />
                </button>
                <button onClick={handleMinhasReservasClick}>
                  <CalendarDays className="w-6 h-6" style={{ color: '#5D4037' }} />
                </button>
              </>
            )}
            <button onClick={handleAvatarClick}>
              <Avatar user={user} />
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-3xl p-6 shadow-lg mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold" style={{ color: '#5D4037' }}>
              SALA
            </h2>
            <button
              onClick={() => setIsCalendarOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-full text-sm"
              style={{ backgroundColor: '#fef8e1', color: '#5D4037' }}
            >
              <CalendarIcon className="w-4 h-4" />
              {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </button>
          </div>

          <div className="flex items-center gap-2 mb-6">
            <button
              onClick={handlePrevWeek}
              disabled={weekStartIndex === 0}
              className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30"
            >
              <ChevronLeft className="w-5 h-5" style={{ color: '#8D6E63' }} />
            </button>

            <div className="flex-1 grid grid-cols-7 gap-2">
              {visibleDates.map((date, index) => {
                const isSelected =
                  date.toDateString() === selectedDate.toDateString();
                const today = startOfDay(new Date());
                const isPast = date < today;
                return (
                  <button
                    key={index}
                    onClick={() => !isPast && setSelectedDate(date)}
                    disabled={isPast}
                    className={`flex flex-col items-center gap-1 p-2 rounded-2xl transition-colors ${isPast ? 'opacity-30 cursor-not-allowed' : ''}`}
                    style={
                      isSelected
                        ? { backgroundColor: '#5D4037', color: 'white' }
                        : { color: '#3E2723' }
                    }
                  >
                    <div className="text-xs opacity-70">
                      {format(date, 'EEE', { locale: ptBR }).toUpperCase().substring(0, 3)}
                    </div>
                    <div className="text-lg">{format(date, 'd')}</div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleNextWeek}
              disabled={weekStartIndex + 7 >= weekDates.length}
              className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30"
            >
              <ChevronRight className="w-5 h-5" style={{ color: '#8D6E63' }} />
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl p-6 shadow-lg mb-24"
        >
          <h3 className="text-lg font-bold mb-4" style={{ color: '#5D4037' }}>
            {format(selectedDate, "EEEE, dd/MM", { locale: ptBR }).toUpperCase()}
          </h3>

          <div className="space-y-3">
            {availableTurnos.map((turno) => {
              const isSelected = isTurnoSelected(turno.id);
              return (
                <motion.button
                  key={turno.id}
                  onClick={() => handleTurnoClick(turno)}
                  whileTap={{ scale: 0.98 }}
                  className="w-full text-left px-6 py-4 rounded-full transition-all"
                  style={
                    isSelected
                      ? { backgroundColor: '#C9B8A8', color: '#3E2723' }
                      : { backgroundColor: '#fef8e1', color: '#8D6E63' }
                  }
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div>{turno.nome}</div>
                      <div className="text-sm opacity-70">({turno.horario})</div>
                    </div>
                    <div className="font-semibold">
                      R$ {(turno.preco / 100).toFixed(2).replace('.', ',')}
                    </div>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {totalTurnosSelecionados > 0 && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-2xl p-4"
          >
            <div className="max-w-md mx-auto flex items-center justify-between gap-4">
              <div className="text-sm" style={{ color: '#5D4037' }}>
                {totalTurnosSelecionados} turno{totalTurnosSelecionados > 1 ? 's' : ''}{' '}
                selecionado{totalTurnosSelecionados > 1 ? 's' : ''}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={limparSelecao}
                  className="px-6 py-3 rounded-full border-2 text-sm"
                  style={{ borderColor: '#5D4037', color: '#5D4037' }}
                >
                  Limpar seleção
                </button>
                <button
                  onClick={handleReservarClick}
                  className="px-6 py-3 rounded-full text-white text-sm"
                  style={{ backgroundColor: '#5D4037' }}
                >
                  Reservar turno
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      <CalendarioModal
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
        selectedDate={selectedDate}
        onSelectDate={handleDateSelect}
      />
    </div>
  );
}