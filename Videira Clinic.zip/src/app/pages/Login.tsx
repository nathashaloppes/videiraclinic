import { useState } from "react";
import { useNavigate } from "react-router";
import { ChevronLeft, Eye, EyeOff } from "lucide-react";
import { motion } from "motion/react";
import { useAuth } from "../contexts/AuthContext";
import { useReservas } from "../contexts/ReservasContext";

export function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const { turnosSelecionados } = useReservas();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [lembrarDeMim, setLembrarDeMim] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await login(email, senha, lembrarDeMim);

      // Redirecionar para área admin se for o email do administrador
      if (
        (email === "nathashaloppes@outlook.com" &&
          senha === "@Leleco06") ||
        (email === "videiraclinic@gmail.com" &&
          senha === "Ci061120@") ||
        (email === "iandersoncounter@gmail.com" &&
          senha === "123")
      ) {
        navigate("/admin/reservas");
      } else {
        navigate("/");
      }
    } catch (error) {
      console.error("Erro ao fazer login:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen overflow-x-hidden"
      style={{ backgroundColor: "#fef8e1" }}
    >
      <div className="max-w-md mx-auto px-4 py-6">
        <button
          onClick={() => navigate("/")}
          className="mb-8 p-2 hover:bg-white/50 rounded-full"
        >
          <ChevronLeft
            className="w-6 h-6"
            style={{ color: "#5D4037" }}
          />
        </button>

        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-2xl mb-8"
          style={{ color: "#5D4037" }}
        >
          Entrar
        </motion.h1>

        {turnosSelecionados.length > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6 rounded-r-2xl"
          >
            <p className="text-sm" style={{ color: "#5D4037" }}>
              Após fazer seu login, você voltará para a tela de
              reservas com o turno que selecionou.
            </p>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-6 shadow-lg"
        >
          <div
            className="flex gap-4 mb-8 border-b"
            style={{ borderColor: "#E0E0E0" }}
          >
            <button
              className="pb-3 px-1 border-b-2 transition-colors"
              style={{
                borderColor: "#5D4037",
                color: "#5D4037",
              }}
            >
              Entrar
            </button>
            <button
              onClick={() => navigate("/cadastro")}
              className="pb-3 px-1 text-gray-400"
            >
              Criar conta
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="email"
                placeholder="E-mail*"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{
                  borderColor: "#E0E0E0",
                  color: "#3E2723",
                }}
              />
            </div>

            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Senha*"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-2xl border text-sm pr-12"
                style={{
                  borderColor: "#E0E0E0",
                  color: "#3E2723",
                }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2"
              >
                {showPassword ? (
                  <EyeOff
                    className="w-5 h-5"
                    style={{ color: "#8D6E63" }}
                  />
                ) : (
                  <Eye
                    className="w-5 h-5"
                    style={{ color: "#8D6E63" }}
                  />
                )}
              </button>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={lembrarDeMim}
                  onChange={(e) =>
                    setLembrarDeMim(e.target.checked)
                  }
                  className="w-4 h-4 rounded"
                  style={{ accentColor: "#5D4037" }}
                />
                <span
                  className="text-sm"
                  style={{ color: "#3E2723" }}
                >
                  Lembrar de mim
                </span>
              </label>

              <button
                type="button"
                className="text-sm hover:underline"
                style={{ color: "#8D6E63" }}
              >
                Esqueci a senha
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-full text-white disabled:opacity-50"
              style={{ backgroundColor: "#5D4037" }}
            >
              {isLoading ? "Entrando..." : "Entrar"}
            </button>

            <p className="text-xs text-center text-gray-500">
              Ao continuar, você concorda com nossos termos e
              política de privacidade.
            </p>
          </form>
        </motion.div>
      </div>
    </div>
  );
}