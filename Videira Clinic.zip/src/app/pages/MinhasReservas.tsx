import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Calendar as CalendarIcon, ChevronDown, Edit } from 'lucide-react';
import { motion } from 'motion/react';
import { Logo } from '../components/Logo';
import { useReservas } from '../contexts/ReservasContext';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { EditarReservaClienteModal } from '../components/EditarReservaClienteModal';
import type { Reserva } from '../contexts/ReservasContext';

export function MinhasReservas() {
  const navigate = useNavigate();
  const { obterReservasPorMes } = useReservas();

  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear] = useState(new Date().getFullYear());
  const [isMonthPickerOpen, setIsMonthPickerOpen] = useState(false);
  const [reservaParaEditar, setReservaParaEditar] = useState<Reserva | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  // Ouvir eventos de atualização e cancelamento de reservas
  useEffect(() => {
    const handleReservaCriada = () => {
      setRefreshKey(prev => prev + 1);
    };

    const handleReservaAtualizada = () => {
      setRefreshKey(prev => prev + 1);
      setReservaParaEditar(null);
    };

    const handleReservaCancelada = () => {
      setRefreshKey(prev => prev + 1);
      setReservaParaEditar(null);
    };

    window.addEventListener('reservaCriada', handleReservaCriada);
    window.addEventListener('reservaAtualizada', handleReservaAtualizada);
    window.addEventListener('reservaCancelada', handleReservaCancelada);

    return () => {
      window.removeEventListener('reservaCriada', handleReservaCriada);
      window.removeEventListener('reservaAtualizada', handleReservaAtualizada);
      window.removeEventListener('reservaCancelada', handleReservaCancelada);
    };
  }, []);

  const reservas = obterReservasPorMes(selectedMonth, selectedYear);

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
      <div className="max-w-md mx-auto px-4 py-6">
        <button
          onClick={() => navigate('/')}
          className="mb-2 p-2 hover:bg-white/50 rounded-full"
        >
          <ChevronLeft className="w-6 h-6" style={{ color: '#5D4037' }} />
        </button>

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center mb-8"
        >
          <Logo />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h2 className="text-xl mb-4" style={{ color: '#5D4037' }}>
            Minhas reservas
          </h2>

          <div className="relative">
            <button
              onClick={() => setIsMonthPickerOpen(!isMonthPickerOpen)}
              className="flex items-center gap-2 px-4 py-3 rounded-full text-sm bg-white shadow-md w-full justify-between"
              style={{ color: '#5D4037' }}
            >
              <span>{monthNames[selectedMonth]} de {selectedYear}</span>
              <ChevronDown className="w-4 h-4" />
            </button>

            {isMonthPickerOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-lg p-2 z-10"
              >
                {monthNames.map((month, index) => (
                  <button
                    key={month}
                    onClick={() => {
                      setSelectedMonth(index);
                      setIsMonthPickerOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 rounded-xl hover:bg-gray-100 text-sm"
                    style={{
                      color: index === selectedMonth ? '#5D4037' : '#3E2723',
                      backgroundColor: index === selectedMonth ? '#fef8e1' : 'transparent',
                    }}
                  >
                    {month}
                  </button>
                ))}
              </motion.div>
            )}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-4"
        >
          {reservas.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center shadow-lg">
              <CalendarIcon className="w-12 h-12 mx-auto mb-4" style={{ color: '#8D6E63' }} />
              <p style={{ color: '#5D4037' }}>
                Nenhuma reserva encontrada para este mês.
              </p>
            </div>
          ) : (
            reservas.map((reserva) => (
              <div
                key={reserva.id}
                className="bg-white rounded-3xl p-6 shadow-lg"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="text-base mb-1" style={{ color: '#3E2723' }}>
                      {reserva.turnos[0].nome}
                    </div>
                    <div className="text-sm mb-2" style={{ color: '#8D6E63' }}>
                      {format(reserva.data, "dd 'de' MMMM", { locale: ptBR })} - {reserva.turnos[0].horario}
                    </div>
                    <div className="text-sm" style={{ color: '#5D4037' }}>
                      R$ {(reserva.total / 100).toFixed(2).replace('.', ',')}
                    </div>
                  </div>
                  <button
                    onClick={() => setReservaParaEditar(reserva)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <Edit className="w-5 h-5" style={{ color: '#8D6E63' }} />
                  </button>
                </div>
              </div>
            ))
          )}
        </motion.div>
      </div>
      {reservaParaEditar && (
        <EditarReservaClienteModal
          reserva={reservaParaEditar}
          onClose={() => setReservaParaEditar(null)}
        />
      )}
    </div>
  );
}