import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { ChevronLeft, User, Calendar as CalendarIcon, Copy, Check, Wallet } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { useReservas } from '../contexts/ReservasContext';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { db } from '../services/database';

export function Pagamento() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { turnosSelecionados, criarReserva } = useReservas();

  const [showQRCode, setShowQRCode] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(300);
  const [pixKey, setPixKey] = useState('');
  const [copiedKey, setCopiedKey] = useState(false);
  const [creditos, setCreditos] = useState(0);
  const [usarCredito, setUsarCredito] = useState(false);
  const [usarPix, setUsarPix] = useState(true);
  const [valorCreditoPersonalizado, setValorCreditoPersonalizado] = useState('');

  // Verificar se vem de uma alteração de reserva
  const valorDiferenca = (location.state as any)?.valorDiferenca || 0;
  const reservaId = (location.state as any)?.reservaId;

  const allTurnos = turnosSelecionados.flatMap((item) =>
    item.turnos.map((turno) => ({
      ...turno,
      data: item.data,
    }))
  );

  const totalOriginal = valorDiferenca > 0 ? valorDiferenca / 100 : allTurnos.reduce((sum, turno) => sum + (turno.preco / 100), 0);

  // Calcular valor de crédito a usar (parseValorCredito retorna em centavos)
  const parseValorCredito = (formatted: string): number => {
    const numbers = formatted.replace(/\D/g, '');
    if (!numbers) return 0;
    return parseFloat(numbers);
  };

  // creditoUtilizado em reais, creditos em centavos
  const creditoUtilizado = usarCredito
    ? (valorCreditoPersonalizado
        ? Math.min(parseValorCredito(valorCreditoPersonalizado) / 100, creditos / 100, totalOriginal)
        : Math.min(creditos / 100, totalOriginal))
    : 0;

  const valorComCredito = totalOriginal - creditoUtilizado;

  useEffect(() => {
    if (user) {
      const creditosArmazenados = db.getCredito(user.id);
      setCreditos(creditosArmazenados);
    }
  }, [user]);

  useEffect(() => {
    if (showQRCode) {
      const timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [showQRCode]);

  const handlePagar = () => {
    const randomKey = `${Math.random().toString(36).substring(2, 15)}-${Math.random().toString(36).substring(2, 15)}-${Math.random().toString(36).substring(2, 15)}`;
    setPixKey(randomKey);
    setShowQRCode(true);
  };

  const handleCopyKey = async () => {
    await navigator.clipboard.writeText(pixKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleSimularPagamento = async () => {
    if (user) {
      if (!reservaId) {
        // Nova reserva - creditoUtilizado precisa estar em centavos
        await criarReserva(user.id, user, creditoUtilizado * 100);
      } else {
        // Alteração de reserva
        const novaData = (location.state as any)?.novaData;
        const novoTurno = (location.state as any)?.novoTurno;

        if (novaData && novoTurno) {
          // Atualizar reserva no banco de dados
          db.updateReserva(reservaId, {
            data: format(novaData, 'yyyy-MM-dd'),
            inicio: novoTurno.horario.split(' às ')[0].replace('h', ':'),
            fim: novoTurno.horario.split(' às ')[1].replace('h', ':'),
            periodo: novoTurno.nome,
            valor: novoTurno.preco,
          });

          // Debitar créditos se foram utilizados (em centavos)
          if (usarCredito && creditoUtilizado > 0) {
            db.debitarCredito(
              user.id,
              creditoUtilizado * 100,
              'Pagamento de diferença de alteração de reserva',
              reservaId
            );
          }

          // Emitir evento para sincronizar
          window.dispatchEvent(new CustomEvent('reservaAtualizada', {
            detail: { reservaId }
          }));
        }
      }

      alert('Pagamento confirmado! Email de confirmação enviado.');
      navigate('/');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatValor = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const numberValue = parseFloat(numbers) / 100;
    return numberValue.toFixed(2).replace('.', ',');
  };

  const handleValorCreditoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatValor(e.target.value);
    setValorCreditoPersonalizado(formatted);
  };

  const handleUsarCreditoToggle = () => {
    if (!usarCredito) {
      setUsarCredito(true);
      setUsarPix(valorComCredito > 0);
    } else {
      setUsarCredito(false);
      setValorCreditoPersonalizado('');
      setUsarPix(true);
    }
  };

  const handleUsarPixToggle = () => {
    setUsarPix(!usarPix);
  };

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
      <div className="max-w-md mx-auto px-4 py-6">
        <button
          onClick={() => navigate('/confirmar-reserva')}
          className="mb-8 p-2 hover:bg-white/50 rounded-full"
        >
          <ChevronLeft className="w-6 h-6" style={{ color: '#5D4037' }} />
        </button>

        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-2xl mb-8"
          style={{ color: '#5D4037' }}
        >
          Confirmar reserva
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-6 shadow-lg mb-4"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm" style={{ color: '#8D6E63' }}>
              Resumo
            </h2>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-start gap-3">
              <User className="w-5 h-5 mt-1" style={{ color: '#8D6E63' }} />
              <div>
                <div className="text-sm" style={{ color: '#3E2723' }}>
                  {user?.nomeCompleto}
                </div>
                <div className="text-xs" style={{ color: '#8D6E63' }}>
                  {user?.email}
                </div>
                <div className="text-xs" style={{ color: '#8D6E63' }}>
                  {user?.telefone}
                </div>
              </div>
            </div>

            <div className="border-t pt-4" style={{ borderColor: '#E0E0E0' }}>
              <div className="flex items-start gap-3">
                <CalendarIcon className="w-5 h-5 mt-1" style={{ color: '#8D6E63' }} />
                <div className="flex-1 space-y-2">
                  <div className="text-sm mb-2" style={{ color: '#3E2723' }}>
                    Sala
                  </div>
                  {allTurnos.map((turno, index) => (
                    <div key={index} className="text-xs" style={{ color: '#8D6E63' }}>
                      {format(turno.data, "EEE, dd/MM", { locale: ptBR })} •{' '}
                      {turno.nome} ({turno.horario}) • R$ {(turno.preco / 100).toFixed(2).replace('.', ',')}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-3xl p-6 shadow-lg"
        >
          <h2 className="text-sm mb-4" style={{ color: '#8D6E63' }}>
            Forma de pagamento
          </h2>

          {/* Opção de Crédito */}
          {creditos > 0 && (
            <div className="mb-3">
              <button
                onClick={handleUsarCreditoToggle}
                className={`flex items-center justify-between px-4 py-3 rounded-2xl w-full border-2 transition-all ${
                  usarCredito ? 'border-[#5D4037]' : 'border-transparent'
                }`}
                style={{ backgroundColor: '#fef8e1' }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: '#8D6E63' }}
                  >
                    <Wallet className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm" style={{ color: '#3E2723' }}>
                      Créditos
                    </div>
                    <div className="text-xs" style={{ color: '#8D6E63' }}>
                      Disponível: R$ {(creditos / 100).toFixed(2).replace('.', ',')}
                    </div>
                  </div>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  usarCredito ? 'bg-[#5D4037] border-[#5D4037]' : 'border-gray-300'
                }`}>
                  {usarCredito && <Check className="w-3 h-3 text-white" />}
                </div>
              </button>

              {/* Campo de valor personalizado */}
              {usarCredito && (
                <div className="mt-3 px-4">
                  <label className="block text-xs mb-2" style={{ color: '#8D6E63' }}>
                    Quanto deseja usar? (Deixe vazio para usar todo o crédito)
                  </label>
                  <input
                    type="text"
                    placeholder="R$ 0,00"
                    value={`R$ ${valorCreditoPersonalizado}`}
                    onChange={handleValorCreditoChange}
                    className="w-full px-4 py-2 rounded-2xl border text-sm"
                    style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                  />
                  <p className="text-xs mt-1" style={{ color: '#8D6E63' }}>
                    {valorCreditoPersonalizado
                      ? `Será usado R$ ${Math.min(parseValorCredito(valorCreditoPersonalizado) / 100, creditos / 100, totalOriginal).toFixed(2).replace('.', ',')}`
                      : `Será usado R$ ${Math.min(creditos / 100, totalOriginal).toFixed(2).replace('.', ',')}`
                    }
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Opção PIX */}
          <button
            onClick={handleUsarPixToggle}
            disabled={valorComCredito === 0}
            className={`flex items-center justify-between px-4 py-3 rounded-2xl mb-6 w-full border-2 transition-all ${
              usarPix && valorComCredito > 0 ? 'border-[#5D4037]' : 'border-transparent'
            } ${valorComCredito === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
            style={{ backgroundColor: '#fef8e1' }}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#32BCAD' }}
              >
                <svg width="20" height="20" viewBox="0 0 20 20" fill="white">
                  <path d="M10 0L12.5 7.5H20L14.5 12L16.5 20L10 15L3.5 20L5.5 12L0 7.5H7.5L10 0Z" />
                </svg>
              </div>
              <div className="text-left">
                <div className="text-sm" style={{ color: '#3E2723' }}>
                  PIX
                </div>
                <div className="text-xs" style={{ color: '#8D6E63' }}>
                  {valorComCredito === 0 ? 'Não necessário' : 'Pagamento instantâneo'}
                </div>
              </div>
            </div>
            {valorComCredito > 0 && (
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                usarPix ? 'bg-[#5D4037] border-[#5D4037]' : 'border-gray-300'
              }`}>
                {usarPix && <Check className="w-3 h-3 text-white" />}
              </div>
            )}
          </button>

          <div className="border-t pt-4 mb-6" style={{ borderColor: '#E0E0E0' }}>
            {usarCredito && creditoUtilizado > 0 && (
              <div className="mb-4 p-3 rounded-2xl" style={{ backgroundColor: '#E8F5E9' }}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs" style={{ color: '#388E3C' }}>
                    Valor total
                  </span>
                  <span className="text-xs" style={{ color: '#388E3C' }}>
                    R$ {totalOriginal.toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs" style={{ color: '#388E3C' }}>
                    Créditos utilizados
                  </span>
                  <span className="text-xs" style={{ color: '#388E3C' }}>
                    - R$ {creditoUtilizado.toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>
            )}

            <div className="flex justify-between items-center mb-6">
              <span className="text-sm" style={{ color: '#8D6E63' }}>
                {usarCredito && creditoUtilizado > 0 ? 'A pagar' : 'Total'}
              </span>
              <span className="text-2xl" style={{ color: '#5D4037' }}>
                R$ {valorComCredito.toFixed(2).replace('.', ',')}
              </span>
            </div>

            {showQRCode && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-6"
              >
                <div className="bg-white border-2 rounded-2xl p-6 mb-4" style={{ borderColor: '#E0E0E0' }}>
                  <div className="w-48 h-48 mx-auto mb-4 bg-gray-200 rounded-2xl flex items-center justify-center">
                    <div className="text-center text-xs" style={{ color: '#8D6E63' }}>
                      QR Code PIX<br />(Mock)
                    </div>
                  </div>

                  <div className="text-center mb-4">
                    <div className="text-sm mb-2" style={{ color: '#5D4037' }}>
                      Tempo restante: {formatTime(timeRemaining)}
                    </div>
                    <div className="text-xs" style={{ color: '#8D6E63' }}>
                      Ao confirmar, você concorda com os Termos e condições da clínica.
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-3 mb-3">
                    <div className="text-xs mb-1" style={{ color: '#8D6E63' }}>
                      Chave PIX:
                    </div>
                    <div className="text-xs break-all" style={{ color: '#3E2723' }}>
                      {pixKey}
                    </div>
                  </div>

                  <button
                    onClick={handleCopyKey}
                    className="w-full py-2 rounded-full border-2 flex items-center justify-center gap-2 text-sm"
                    style={{ borderColor: '#5D4037', color: '#5D4037' }}
                  >
                    {copiedKey ? (
                      <>
                        <Check className="w-4 h-4" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copiar chave PIX
                      </>
                    )}
                  </button>
                </div>

                <button
                  onClick={handleSimularPagamento}
                  className="w-full py-3 rounded-full text-white text-sm mb-2"
                  style={{ backgroundColor: '#32BCAD' }}
                >
                  [Simular Pagamento Confirmado]
                </button>
              </motion.div>
            )}

            {!showQRCode && (
              <button
                onClick={valorComCredito === 0 ? handleSimularPagamento : (usarPix ? handlePagar : handleSimularPagamento)}
                disabled={!usarPix && valorComCredito > 0}
                className="w-full py-3 rounded-full text-white disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ backgroundColor: '#5D4037' }}
              >
                {valorComCredito === 0 ? 'Confirmar' : (usarPix ? 'Pagar' : 'Selecione uma forma de pagamento')}
              </button>
            )}
          </div>

          <p className="text-xs text-center" style={{ color: '#8D6E63' }}>
            Ao confirmar, você concorda com os Termos e condições da clínica.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
