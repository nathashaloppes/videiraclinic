import { useState } from 'react';
import { useNavigate } from 'react-router';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ChevronRight, Plus } from 'lucide-react';
import { AdicionarClienteModal } from '../../components/admin/modals/AdicionarClienteModal';
import { useAdmin, type Cliente } from '../../contexts/AdminContext';

export function AdminClientes() {
  const navigate = useNavigate();
  const { clientes, adicionarCliente } = useAdmin();
  const [modalAdicionar, setModalAdicionar] = useState(false);

  const handleAdicionarCliente = (novoCliente: Omit<Cliente, 'id' | 'numeroReservas'>) => {
    adicionarCliente(novoCliente);
    setModalAdicionar(false);
  };

  return (
    <AdminLayout>
      <div className="pb-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl" style={{ color: '#3E2723' }}>Clientes</h1>

          <button
            onClick={() => setModalAdicionar(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-full"
            style={{ backgroundColor: '#D7CCC8', color: '#3E2723' }}
          >
            <span className="text-sm">Adicionar</span>
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          {clientes.map((cliente) => {
            const iniciais = cliente.nomeCompleto
              .split(' ')
              .map((n) => n[0])
              .join('')
              .toUpperCase()
              .slice(0, 2);

            return (
              <button
                key={cliente.id}
                onClick={() => navigate('/admin/clientes/detalhes', { state: { cliente } })}
                className="w-full bg-white rounded-2xl p-4 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: '#BCAAA4' }}
                  >
                    {iniciais}
                  </div>
                  <div className="text-left">
                    <h3 style={{ color: '#3E2723' }}>{cliente.nomeCompleto}</h3>
                    <p className="text-sm text-gray-500">{cliente.email}</p>
                    {cliente.numeroReservas > 0 ? (
                      <p className="text-sm" style={{ color: '#5D4037' }}>
                        {cliente.numeroReservas} {cliente.numeroReservas === 1 ? 'reserva' : 'reservas'}
                      </p>
                    ) : (
                      <p className="text-sm text-gray-400">Nenhuma reserva</p>
                    )}
                  </div>
                </div>

                <ChevronRight className="w-5 h-5" style={{ color: '#8D6E63' }} />
              </button>
            );
          })}
        </div>
      </div>

      {modalAdicionar && (
        <AdicionarClienteModal
          onClose={() => setModalAdicionar(false)}
          onSave={handleAdicionarCliente}
        />
      )}
    </AdminLayout>
  );
}