import { useState, useEffect, useRef } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Calendar, Plus, Trash2, ChevronLeft, ChevronRight, GripVertical } from 'lucide-react';
import { CalendarioAdminModal } from '../../components/CalendarioAdminModal';
import { AdicionarTurnoModal } from '../../components/admin/modals/AdicionarTurnoModal';
import { ErroTurnoModal } from '../../components/admin/modals/ErroTurnoModal';
import { ExcluirTurnoModal } from '../../components/admin/modals/ExcluirTurnoModal';
import { format, addDays, differenceInDays, addMonths, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAdmin, type Turno } from '../../contexts/AdminContext';
import { toast } from 'sonner';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

interface TurnoItemProps {
  turno: Turno;
  index: number;
  moveTurno: (dragIndex: number, hoverIndex: number) => void;
  finalizarReordenacao: () => void;
  handleToggleTurno: (id: string) => void;
  getValorDisplay: (turno: Turno) => string;
  handleValorChange: (e: React.ChangeEvent<HTMLInputElement>, id: string) => void;
  handleValorBlur: (id: string) => void;
  setTurnoParaExcluir: (id: string) => void;
}

const TurnoItem = ({ turno, index, moveTurno, finalizarReordenacao, handleToggleTurno, getValorDisplay, handleValorChange, handleValorBlur, setTurnoParaExcluir }: TurnoItemProps) => {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isOver }, drop] = useDrop({
    accept: 'turno',
    hover(item: { id: string; index: number }, monitor) {
      if (!ref.current) {
        return;
      }

      const dragIndex = item.index;
      const hoverIndex = index;

      // Don't replace items with themselves
      if (dragIndex === hoverIndex) {
        return;
      }

      // Determine rectangle on screen
      const hoverBoundingRect = ref.current.getBoundingClientRect();

      // Get vertical middle
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;

      // Determine mouse position
      const clientOffset = monitor.getClientOffset();
      if (!clientOffset) return;

      // Get pixels to the top
      const hoverClientY = clientOffset.y - hoverBoundingRect.top;

      // Dragging downwards
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      // Dragging upwards
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      // Time to actually perform the action - move immediately
      moveTurno(dragIndex, hoverIndex);

      // Update the index for the dragged item
      item.index = hoverIndex;
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });

  const [{ isDragging }, drag] = useDrag({
    type: 'turno',
    item: () => {
      return { id: turno.id, index };
    },
    end: (item, monitor) => {
      finalizarReordenacao();
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const opacity = isDragging ? 0.4 : 1;
  const backgroundColor = turno.ativo ? 'white' : '#f5f5f5';

  drag(drop(ref));

  return (
    <div
      ref={ref}
      className={`rounded-2xl p-5 flex items-center gap-4 ${
        turno.ativo ? 'shadow-sm' : ''
      } ${isOver ? 'ring-2 ring-[#5D4037]' : ''}`}
      style={{
        opacity,
        backgroundColor: isOver ? '#FEF3E2' : backgroundColor,
        transition: 'all 0.15s ease-out',
        transform: isOver ? 'scale(1.02)' : 'scale(1)',
      }}
    >
      <button
        onClick={() => handleToggleTurno(turno.id)}
        disabled={turno.id.startsWith('reserva_')}
        className="relative w-14 h-7 rounded-full flex-shrink-0"
        style={{
          backgroundColor: turno.ativo ? '#5D4037' : '#BCAAA4',
          opacity: turno.id.startsWith('reserva_') ? 0.5 : 1,
          cursor: turno.id.startsWith('reserva_') ? 'not-allowed' : 'pointer',
        }}
      >
        <div
          className={`absolute top-0.5 w-6 h-6 bg-white rounded-full transition-transform ${
            turno.ativo ? 'translate-x-7' : 'translate-x-0.5'
          }`}
        />
      </button>

      <div className="flex-1">
        <div className="mb-1" style={{ color: turno.ativo ? '#3E2723' : '#9E9E9E' }}>
          {turno.periodo}
        </div>
        <div className="text-sm mb-2" style={{ color: turno.ativo ? '#8D6E63' : '#BCAAA4' }}>
          ({turno.inicio} às {turno.fim})
        </div>
        <input
          type="text"
          placeholder="R$ 0,00"
          value={getValorDisplay(turno)}
          onChange={(e) => handleValorChange(e, turno.id)}
          onBlur={() => handleValorBlur(turno.id)}
          autoComplete="transaction-amount"
          inputMode="numeric"
          readOnly={turno.id.startsWith('reserva_')}
          className={`w-28 px-3 py-2 rounded-xl border text-sm ${turno.id.startsWith('reserva_') ? 'bg-gray-100 cursor-not-allowed' : ''}`}
          style={{ color: turno.ativo ? '#3E2723' : '#9E9E9E' }}
        />
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => setTurnoParaExcluir(turno.id)}
          className="p-2 hover:bg-red-50 rounded-full flex-shrink-0"
          disabled={turno.id.startsWith('reserva_')}
          style={{ opacity: turno.id.startsWith('reserva_') ? 0.3 : 1 }}
        >
          <Trash2 className="w-4 h-4 text-red-600" />
        </button>

        <div
          ref={drag}
          className="p-2 flex-shrink-0 cursor-grab active:cursor-grabbing"
          style={{
            opacity: turno.id.startsWith('reserva_') ? 0.3 : 1,
            cursor: turno.id.startsWith('reserva_') ? 'not-allowed' : isDragging ? 'grabbing' : 'grab'
          }}
        >
          <GripVertical className="w-5 h-5" style={{ color: '#8D6E63' }} />
        </div>
      </div>
    </div>
  );
};

export function AdminConfigurar() {
  const {
    obterTurnosPorData,
    adicionarTurnoNaData,
    atualizarTurnoNaData,
    excluirTurnoNaData,
    ativarDesativarTurnoNaData,
    salvarOrdemTurnos
  } = useAdmin();

  const [dataSelecionada, setDataSelecionada] = useState(() => addDays(startOfDay(new Date()), 1));
  const [calendarioAberto, setCalendarioAberto] = useState(false);
  const [modalAdicionar, setModalAdicionar] = useState(false);
  const [erroTurno, setErroTurno] = useState(false);
  const [erroMensagem, setErroMensagem] = useState('');
  const [turnoParaExcluir, setTurnoParaExcluir] = useState<string | null>(null);
  const [weekDates, setWeekDates] = useState<Date[]>([]);
  const [weekStartIndex, setWeekStartIndex] = useState(0);

  useEffect(() => {
    const today = startOfDay(new Date());
    const tomorrow = addDays(today, 1);
    const maxDate = addMonths(tomorrow, 3);

    const totalDays = differenceInDays(maxDate, tomorrow) + 1;
    const dates = Array.from({ length: totalDays }, (_, i) => addDays(tomorrow, i));
    setWeekDates(dates);
    setWeekStartIndex(0);
  }, []);

  const visibleDates = weekDates.slice(weekStartIndex, weekStartIndex + 7);

  const updateWeekForDate = (date: Date) => {
    if (weekDates.length === 0) return;
    const today = startOfDay(new Date());
    const daysSinceToday = differenceInDays(date, today);
    const newWeekIndex = Math.max(0, Math.floor(daysSinceToday / 7) * 7);
    if (newWeekIndex < weekDates.length) {
      setWeekStartIndex(newWeekIndex);
    }
  };

  const handleSelecionarData = (data: Date) => {
    setDataSelecionada(data);
    updateWeekForDate(data);
    setCalendarioAberto(false);
  };

  const handleNextWeek = () => {
    if (weekStartIndex + 7 < weekDates.length) {
      setWeekStartIndex(weekStartIndex + 7);
    }
  };

  const handlePrevWeek = () => {
    if (weekStartIndex - 7 >= 0) {
      setWeekStartIndex(weekStartIndex - 7);
    }
  };

  const [turnosOrdenados, setTurnosOrdenados] = useState<Turno[]>([]);
  const turnosOrdenadosRef = useRef<Turno[]>([]);
  const [valoresEditando, setValoresEditando] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    // Carregar turnos quando a data muda
    const turnosAtualizados = obterTurnosPorData(dataSelecionada);
    setTurnosOrdenados(turnosAtualizados);
    turnosOrdenadosRef.current = turnosAtualizados;
  }, [dataSelecionada]);

  useEffect(() => {
    const handleTurnosAtualizados = () => {
      const turnosAtualizados = obterTurnosPorData(dataSelecionada);
      setTurnosOrdenados(turnosAtualizados);
      turnosOrdenadosRef.current = turnosAtualizados;
    };

    window.addEventListener('turnosAtualizados', handleTurnosAtualizados);
    return () => window.removeEventListener('turnosAtualizados', handleTurnosAtualizados);
  }, [dataSelecionada]);

  const moveTurno = (dragIndex: number, hoverIndex: number) => {
    setTurnosOrdenados(prevTurnos => {
      const turnosAtualizados = [...prevTurnos];
      const [turnoMovido] = turnosAtualizados.splice(dragIndex, 1);
      turnosAtualizados.splice(hoverIndex, 0, turnoMovido);
      turnosOrdenadosRef.current = turnosAtualizados;
      return turnosAtualizados;
    });
  };

  const finalizarReordenacao = () => {
    // Salvar a ordem final no AdminContext usando o ref atualizado
    salvarOrdemTurnos(dataSelecionada, turnosOrdenadosRef.current);
  };

  const handleToggleTurno = (id: string) => {
    const sucesso = ativarDesativarTurnoNaData(dataSelecionada, id);
    if (!sucesso) {
      setErroMensagem('Turno Reservado');
      setErroTurno(true);
    }
  };

  const handleAdicionarTurno = (novoTurno: Omit<Turno, 'id' | 'ativo'>) => {
    const sucesso = adicionarTurnoNaData(dataSelecionada, novoTurno);
    if (sucesso) {
      setModalAdicionar(false);
      toast.success('Turno adicionado com sucesso!');
    } else {
      setModalAdicionar(false);
      setErroMensagem('Turno Reservado');
      setErroTurno(true);
    }
  };

  const handleExcluirTurno = () => {
    if (turnoParaExcluir) {
      const sucesso = excluirTurnoNaData(dataSelecionada, turnoParaExcluir);
      if (sucesso) {
        setTurnoParaExcluir(null);
        toast.success('Turno excluído com sucesso!');
      } else {
        setTurnoParaExcluir(null);
        setErroMensagem('Turno Reservado');
        setErroTurno(true);
      }
    }
  };

  const formatValor = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const numberValue = parseFloat(numbers) / 100;
    return numberValue.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const parseValor = (formatted: string): number => {
    const numbers = formatted.replace(/\D/g, '');
    if (!numbers) return 0;
    return parseFloat(numbers);
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
    const formatted = formatValor(e.target.value);
    setValoresEditando(prev => ({
      ...prev,
      [id]: formatted
    }));
  };

  const handleValorBlur = (id: string) => {
    const valorFormatado = valoresEditando[id];
    if (valorFormatado === undefined) return;

    const valorEmCentavos = parseValor(valorFormatado);

    // Atualizar estado local imediatamente
    setTurnosOrdenados(prevTurnos => {
      const turnosAtualizados = prevTurnos.map(t =>
        t.id === id ? { ...t, valor: valorEmCentavos } : t
      );
      turnosOrdenadosRef.current = turnosAtualizados;
      return turnosAtualizados;
    });

    // Atualizar no contexto
    atualizarTurnoNaData(dataSelecionada, id, {
      valor: valorEmCentavos,
    });
  };

  const getValorDisplay = (turno: Turno): string => {
    if (valoresEditando[turno.id] !== undefined) {
      return valoresEditando[turno.id];
    }
    const centavos = turno.valor || 0;
    return (centavos / 100).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  return (
    <AdminLayout>
      <div className="pb-6">

        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl" style={{ color: '#3E2723' }}>Turnos</h1>

          <button
            onClick={() => setModalAdicionar(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-full"
            style={{ backgroundColor: '#D7CCC8', color: '#3E2723' }}
          >
            <span className="text-sm">Adicionar</span>
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={() => setCalendarioAberto(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-full mb-4 w-full justify-center"
          style={{ backgroundColor: '#D7CCC8', color: '#3E2723' }}
        >
          <Calendar className="w-4 h-4" />
          <span className="text-sm">
            {format(dataSelecionada, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
          </span>
        </button>

        <div className="flex items-center gap-2 mb-6">
          <button
            onClick={handlePrevWeek}
            disabled={weekStartIndex === 0}
            className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30"
          >
            <ChevronLeft className="w-5 h-5" style={{ color: '#8D6E63' }} />
          </button>

          <div className="flex-1 grid grid-cols-7 gap-2">
            {visibleDates.map((date, index) => {
              const isSelected = date.toDateString() === dataSelecionada.toDateString();
              const today = startOfDay(new Date());
              const isPast = date < today;
              return (
                <button
                  key={index}
                  onClick={() => !isPast && setDataSelecionada(date)}
                  disabled={isPast}
                  className={`flex flex-col items-center gap-1 p-2 rounded-2xl transition-colors ${isPast ? 'opacity-30 cursor-not-allowed' : ''}`}
                  style={
                    isSelected
                      ? { backgroundColor: '#5D4037', color: 'white' }
                      : { color: '#3E2723' }
                  }
                >
                  <div className="text-xs opacity-70">
                    {format(date, 'EEE', { locale: ptBR }).toUpperCase().substring(0, 3)}
                  </div>
                  <div className="text-lg">{format(date, 'd')}</div>
                </button>
              );
            })}
          </div>

          <button
            onClick={handleNextWeek}
            disabled={weekStartIndex + 7 >= weekDates.length}
            className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30"
          >
            <ChevronRight className="w-5 h-5" style={{ color: '#8D6E63' }} />
          </button>
        </div>

        <DndProvider backend={HTML5Backend}>
          <div className="space-y-3">
            {turnosOrdenados.map((turno, index) => (
              <TurnoItem
                key={turno.id}
                turno={turno}
                index={index}
                moveTurno={moveTurno}
                finalizarReordenacao={finalizarReordenacao}
                handleToggleTurno={handleToggleTurno}
                getValorDisplay={getValorDisplay}
                handleValorChange={handleValorChange}
                handleValorBlur={handleValorBlur}
                setTurnoParaExcluir={setTurnoParaExcluir}
              />
            ))}
          </div>
        </DndProvider>

      </div>

      <CalendarioAdminModal
        isOpen={calendarioAberto}
        onClose={() => setCalendarioAberto(false)}
        onSelectDate={handleSelecionarData}
        selectedDate={dataSelecionada}
      />

      {modalAdicionar && (
        <AdicionarTurnoModal
          onClose={() => setModalAdicionar(false)}
          onSave={handleAdicionarTurno}
        />
      )}

      {erroTurno && (
        <ErroTurnoModal
          onClose={() => setErroTurno(false)}
          mensagem={erroMensagem}
        />
      )}

      {turnoParaExcluir && (
        <ExcluirTurnoModal
          onClose={() => setTurnoParaExcluir(null)}
          onConfirm={handleExcluirTurno}
        />
      )}

    </AdminLayout>
  );
}