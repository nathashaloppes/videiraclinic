import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Calendar, Edit } from 'lucide-react';
import { CalendarioAdminModal } from '../../components/CalendarioAdminModal';
import { EditarReservaModal } from '../../components/admin/modals/EditarReservaModal';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAdmin, type Reserva } from '../../contexts/AdminContext';

export function AdminReservas() {
  const { reservas, atualizarReserva } = useAdmin();
  const [filtroData, setFiltroData] = useState<Date | null>(null);
  const [calendarioAberto, setCalendarioAberto] = useState(false);
  const [reservaParaEditar, setReservaParaEditar] = useState<Reserva | null>(null);
  const [filtroSelecionado, setFiltroSelecionado] = useState('Selecione uma data');

  const handleSelecionarData = (data: Date) => {
    setFiltroData(data);
    setFiltroSelecionado(format(data, "dd 'de' MMMM 'de' yyyy", { locale: ptBR }));
    setCalendarioAberto(false);
  };

  const reservasFiltradas = filtroData
    ? reservas.filter(
        (r) =>
          r.data.getDate() === filtroData.getDate() &&
          r.data.getMonth() === filtroData.getMonth() &&
          r.data.getFullYear() === filtroData.getFullYear()
      )
    : reservas;

  return (
    <AdminLayout>
      <>
        <div className="pb-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl" style={{ color: '#3E2723' }}>Reservas</h1>

            <button
              onClick={() => setCalendarioAberto(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-full"
              style={{ backgroundColor: '#D7CCC8', color: '#3E2723' }}
            >
              <Calendar className="w-4 h-4" />
              <span className="text-sm">{filtroSelecionado}</span>
            </button>
          </div>

          {reservasFiltradas.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center shadow-lg">
              <Calendar className="w-12 h-12 mx-auto mb-4" style={{ color: '#8D6E63' }} />
              <p style={{ color: '#5D4037' }}>Nenhuma reserva encontrada.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {reservasFiltradas.map((reserva) => {
              const iniciais = reserva.clienteNome
                .split(' ')
                .map((n) => n[0])
                .join('')
                .toUpperCase()
                .slice(0, 2);

              return (
                <div
                  key={reserva.id}
                  className="bg-white rounded-2xl p-4 shadow-sm"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-white flex-shrink-0"
                        style={{ backgroundColor: '#BCAAA4' }}
                      >
                        {iniciais}
                      </div>
                      <div className="flex-1">
                        <h3 style={{ color: '#3E2723' }}>{reserva.clienteNome}</h3>
                        <p className="text-sm text-gray-500 mb-2">{reserva.clienteEmail}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {format(reserva.data, "EEE, dd 'de' MMMM", { locale: ptBR })} · {reserva.inicio} às {reserva.fim}
                          </span>
                        </div>
                        <p className="text-sm mt-1" style={{ color: '#5D4037' }}>
                          R$ {(reserva.valor / 100).toFixed(2).replace('.', ',')}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => setReservaParaEditar(reserva)}
                      className="p-2 hover:bg-gray-100 rounded-full flex-shrink-0"
                    >
                      <Edit className="w-5 h-5" style={{ color: '#5D4037' }} />
                    </button>
                  </div>
                </div>
              );
            })}
            </div>
          )}
        </div>

        <CalendarioAdminModal
          isOpen={calendarioAberto}
          onClose={() => setCalendarioAberto(false)}
          onSelectDate={handleSelecionarData}
          selectedDate={filtroData || new Date()}
        />

        {reservaParaEditar && (
          <EditarReservaModal
            reserva={reservaParaEditar}
            onClose={() => setReservaParaEditar(null)}
            onSave={(reservaAtualizada) => {
              atualizarReserva(reservaAtualizada.id, reservaAtualizada);
              setReservaParaEditar(null);
            }}
          />
        )}
      </>
    </AdminLayout>
  );
}
