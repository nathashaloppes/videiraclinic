import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { ChevronLeft, Edit, Calendar, Phone, Mail, MapPin, Plus, Wallet, Award, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EditarClienteModal } from '../../components/admin/modals/EditarClienteModal';
import { AdicionarTurnoModal } from '../../components/admin/modals/AdicionarTurnoModal';
import { CalendarioAdminModal } from '../../components/CalendarioAdminModal';
import { ErroTurnoModal } from '../../components/admin/modals/ErroTurnoModal';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Logo } from '../../components/Logo';
import { useAdmin, type Cliente, type Turno } from '../../contexts/AdminContext';
import { toast } from 'sonner';
import { db } from '../../services/database';

export function DetalhesCliente() {
  const navigate = useNavigate();
  const location = useLocation();
  const { clientes, obterReservasPorCliente, atualizarCliente, excluirCliente, adicionarTurnoNaData, adicionarReserva } = useAdmin();

  const clienteInicial = location.state?.cliente as Cliente;
  const [clienteId] = useState(clienteInicial?.id);
  const [modalEditar, setModalEditar] = useState(false);
  const [modalExcluir, setModalExcluir] = useState(false);
  const [modalAdicionarTurno, setModalAdicionarTurno] = useState(false);
  const [calendarioAberto, setCalendarioAberto] = useState(false);
  const [dataSelecionada, setDataSelecionada] = useState(new Date());
  const [erroMensagem, setErroMensagem] = useState('');
  const [erroTurno, setErroTurno] = useState(false);
  const [creditos, setCreditos] = useState(0);
  const [modalAdicionarCredito, setModalAdicionarCredito] = useState(false);
  const [modalExcluirCredito, setModalExcluirCredito] = useState(false);
  const [valorCredito, setValorCredito] = useState('');
  const [valorExcluir, setValorExcluir] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  // Buscar cliente atualizado do contexto
  const cliente = clientes.find((c) => c.id === clienteId);

  // Escutar eventos de atualização de reservas
  useEffect(() => {
    const handleReservaEvent = () => {
      setRefreshKey(prev => prev + 1);
    };

    window.addEventListener('reservaCriada', handleReservaEvent);
    window.addEventListener('reservaAtualizada', handleReservaEvent);
    window.addEventListener('reservaCancelada', handleReservaEvent);

    return () => {
      window.removeEventListener('reservaCriada', handleReservaEvent);
      window.removeEventListener('reservaAtualizada', handleReservaEvent);
      window.removeEventListener('reservaCancelada', handleReservaEvent);
    };
  }, []);

  useEffect(() => {
    if (!cliente) {
      navigate('/admin/clientes');
    }
  }, [cliente, navigate]);

  // Carregar créditos do cliente
  useEffect(() => {
    if (clienteId) {
      const creditosCliente = db.getCredito(clienteId);
      setCreditos(creditosCliente);
    }
  }, [clienteId]);

  // Obter reservas e atualizar quando refreshKey muda
  const [reservas, setReservas] = useState<any[]>([]);

  useEffect(() => {
    if (cliente) {
      const reservasAtualizadas = obterReservasPorCliente(cliente.id);
      setReservas(reservasAtualizadas);
    }
  }, [refreshKey, cliente, obterReservasPorCliente]);

  if (!cliente) {
    return null;
  }

  const handleExcluirCliente = () => {
    // Verificar primeiro se tem crédito positivo
    const creditoCliente = db.getCredito(cliente.id);
    if (creditoCliente > 0) {
      setModalExcluir(false);
      setErroMensagem('Cliente com crédito positivo');
      setErroTurno(true);
      return;
    }

    // Depois verificar se tem reservas futuras
    const sucesso = excluirCliente(cliente.id);
    if (sucesso) {
      setModalExcluir(false);
      navigate('/admin/clientes');
      toast.success('Cliente excluído com sucesso!');
    } else {
      setModalExcluir(false);
      setErroMensagem('Reserva em andamento');
      setErroTurno(true);
    }
  };

  const handleSelecionarData = (data: Date) => {
    setDataSelecionada(data);
    setCalendarioAberto(false);
    setModalAdicionarTurno(true);
  };

  const handleAdicionarTurno = (novoTurno: Omit<Turno, 'id' | 'ativo'>) => {
    // Buscar turnos da data selecionada
    const dataString = `${dataSelecionada.getFullYear()}-${String(dataSelecionada.getMonth() + 1).padStart(2, '0')}-${String(dataSelecionada.getDate()).padStart(2, '0')}`;
    const turnosPorData = (window as any).__turnosPorData || [];
    const turnosDaData = turnosPorData.find((t: any) => t.data === dataString);

    // Função auxiliar para verificar sobreposição de horários
    const horarioDentroDeOutro = (inicio1: string, fim1: string, inicio2: string, fim2: string): boolean => {
      const [h1i, m1i] = inicio1.split(':').map(Number);
      const [h1f, m1f] = fim1.split(':').map(Number);
      const [h2i, m2i] = inicio2.split(':').map(Number);
      const [h2f, m2f] = fim2.split(':').map(Number);

      const min1i = h1i * 60 + m1i;
      const min1f = h1f * 60 + m1f;
      const min2i = h2i * 60 + m2i;
      const min2f = h2f * 60 + m2f;

      return (min1i < min2f && min1f > min2i);
    };

    // Verificar se já existe uma reserva que colide com este horário
    const reservasExistentes = db.getReservasByData(dataString);
    const reservaColidindo = reservasExistentes.find(r =>
      r.status === 'confirmada' && horarioDentroDeOutro(novoTurno.inicio, novoTurno.fim, r.inicio, r.fim)
    );

    if (reservaColidindo) {
      setModalAdicionarTurno(false);
      setErroMensagem('Horário já reservado');
      setErroTurno(true);
      return;
    }

    let turnosIds: string[] = [];

    // Se existem turnos na data, coletar os IDs dos turnos que se sobrepõem
    if (turnosDaData) {
      const turnosCorrespondentes = turnosDaData.turnos.filter((t: any) =>
        horarioDentroDeOutro(novoTurno.inicio, novoTurno.fim, t.inicio, t.fim) && t.ativo
      );
      turnosIds = turnosCorrespondentes.map((t: any) => t.id);
    }

    // Se não há turnos correspondentes, criar um novo
    if (turnosIds.length === 0) {
      adicionarTurnoNaData(dataSelecionada, novoTurno);

      // Buscar novamente para pegar o ID do turno criado
      setTimeout(() => {
        const turnosPorDataAtualizado = (window as any).__turnosPorData || [];
        const turnosDaDataAtualizado = turnosPorDataAtualizado.find((t: any) => t.data === dataString);

        if (turnosDaDataAtualizado) {
          const turnoRecemCriado = turnosDaDataAtualizado.turnos.find((t: any) =>
            t.inicio === novoTurno.inicio &&
            t.fim === novoTurno.fim &&
            t.periodo === novoTurno.periodo
          );
          if (turnoRecemCriado) {
            turnosIds = [turnoRecemCriado.id];
          }
        }

        // Criar reserva para o cliente
        adicionarReserva({
          clienteId: cliente.id,
          clienteNome: cliente.nomeCompleto,
          clienteEmail: cliente.email,
          clienteFoto: cliente.fotoPerfil,
          data: dataSelecionada,
          periodo: novoTurno.periodo,
          inicio: novoTurno.inicio,
          fim: novoTurno.fim,
          valor: novoTurno.valor,
          turnosIds,
        });
      }, 100);
    } else {
      // Criar reserva usando os turnos existentes
      adicionarReserva({
        clienteId: cliente.id,
        clienteNome: cliente.nomeCompleto,
        clienteEmail: cliente.email,
        clienteFoto: cliente.fotoPerfil,
        data: dataSelecionada,
        periodo: novoTurno.periodo,
        inicio: novoTurno.inicio,
        fim: novoTurno.fim,
        valor: novoTurno.valor,
        turnosIds,
      });
    }

    setModalAdicionarTurno(false);
    toast.success('Turno adicionado ao cliente com sucesso!');
  };

  const formatValor = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (!numbers) return '';
    const numberValue = parseFloat(numbers) / 100;
    return numberValue.toFixed(2).replace('.', ',');
  };

  const parseValor = (formatted: string): number => {
    const numbers = formatted.replace(/\D/g, '');
    return parseFloat(numbers);
  };

  const handleAdicionarCredito = () => {
    const valor = parseValor(valorCredito);
    if (valor > 0) {
      db.adicionarCredito(cliente.id, valor, 'Crédito adicionado pelo administrador');
      setCreditos(db.getCredito(cliente.id));
      setModalAdicionarCredito(false);
      setValorCredito('');
      toast.success(`R$ ${(valor / 100).toFixed(2).replace('.', ',')} adicionados aos créditos do cliente!`);
    } else {
      toast.error('Digite um valor válido');
    }
  };

  const handleExcluirCredito = () => {
    const valor = parseValor(valorExcluir);

    if (valor > 0 && valor <= creditos) {
      db.debitarCredito(
        cliente.id,
        valor,
        'Estorno parcial de créditos pelo administrador'
      );
      setCreditos(db.getCredito(cliente.id));
      setModalExcluirCredito(false);
      setValorExcluir('');
      toast.success(`R$ ${(valor / 100).toFixed(2).replace('.', ',')} estornados com sucesso!`);
      window.dispatchEvent(new Event('creditoAtualizado'));
    } else if (valor > creditos) {
      toast.error('Valor maior que o crédito disponível!');
    } else {
      toast.error('Digite um valor válido!');
    }
  };

  const iniciais = cliente.nomeCompleto
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <>
      <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#fef8e1' }}>
        <div className="max-w-md mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={() => navigate('/admin/clientes')}
              className="p-2 hover:bg-white/50 rounded-full"
            >
              <ChevronLeft className="w-6 h-6" style={{ color: '#5D4037' }} />
            </button>

            <h2 className="flex-1 text-center" style={{ color: '#3E2723' }}>
              {cliente.nomeCompleto}
            </h2>

            <button
              onClick={() => setModalEditar(true)}
              className="p-2 hover:bg-white/50 rounded-full"
            >
              <Edit className="w-5 h-5" style={{ color: '#5D4037' }} />
            </button>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center mb-6"
          >
            <div
              className="w-24 h-24 rounded-full flex items-center justify-center text-white text-2xl mb-4"
              style={{ backgroundColor: '#BCAAA4' }}
            >
              {iniciais}
            </div>

            <div className="space-y-3 w-full bg-white rounded-3xl p-6 shadow-lg">
              <div className="flex items-center gap-3">
                <Award className="w-5 h-5" style={{ color: '#8D6E63' }} />
                <span className="text-sm" style={{ color: '#3E2723' }}>
                  {cliente.registroCRO || 'CRO não informado'}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <Briefcase className="w-5 h-5" style={{ color: '#8D6E63' }} />
                <span className="text-sm" style={{ color: '#3E2723' }}>
                  {cliente.areaAtuacao || 'Área não informada'}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5" style={{ color: '#8D6E63' }} />
                <span className="text-sm" style={{ color: '#3E2723' }}>
                  Nascida em {cliente.dataNascimento}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5" style={{ color: '#8D6E63' }} />
                <span className="text-sm" style={{ color: '#3E2723' }}>
                  {cliente.telefone}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5" style={{ color: '#8D6E63' }} />
                <span className="text-sm" style={{ color: '#3E2723' }}>
                  {cliente.email}
                </span>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 mt-1" style={{ color: '#8D6E63' }} />
                <span className="text-sm" style={{ color: '#3E2723' }}>
                  {cliente.endereco}
                </span>
              </div>
            </div>
          </motion.div>

          {/* Carteira do Cliente */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-6"
          >
            <h3 className="mb-4" style={{ color: '#3E2723' }}>
              Carteira do cliente
            </h3>

            <div className="bg-white rounded-3xl p-6 shadow-lg mb-3">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Wallet className="w-6 h-6" style={{ color: '#8D6E63' }} />
                  <div>
                    <p className="text-xs" style={{ color: '#8D6E63' }}>
                      Saldo disponível
                    </p>
                    <p className="text-xl font-bold" style={{ color: '#5D4037' }}>
                      R$ {(creditos / 100).toFixed(2).replace('.', ',')}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setModalAdicionarCredito(true)}
                  className="flex-1 py-2 rounded-full text-sm"
                  style={{ backgroundColor: '#D7CCC8', color: '#3E2723' }}
                >
                  Adicionar crédito
                </button>
                <button
                  onClick={() => setModalExcluirCredito(true)}
                  disabled={creditos === 0}
                  className="flex-1 py-2 rounded-full border-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                  style={{ borderColor: '#D32F2F', color: '#D32F2F' }}
                >
                  Excluir crédito
                </button>
              </div>
            </div>
          </motion.div>

          <div className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 style={{ color: '#3E2723' }}>
                Histórico de reservas
              </h3>
              <button
                onClick={() => setCalendarioAberto(true)}
                className="flex items-center gap-1 px-3 py-2 rounded-full text-sm"
                style={{ backgroundColor: '#D7CCC8', color: '#3E2723' }}
              >
                <Plus className="w-4 h-4" />
                Adicionar
              </button>
            </div>

            {reservas.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 text-center shadow-lg">
                <Calendar className="w-12 h-12 mx-auto mb-4" style={{ color: '#8D6E63' }} />
                <p style={{ color: '#5D4037' }}>Nenhuma reserva encontrada.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {reservas.map((reserva) => (
                  <div key={reserva.id} className="bg-white rounded-2xl p-4 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="mb-1" style={{ color: '#3E2723' }}>
                          {format(reserva.data, "EEEE, dd 'de' MMMM", { locale: ptBR })}
                        </div>
                        <div className="text-sm" style={{ color: '#8D6E63' }}>
                          {reserva.inicio} às {reserva.fim}
                        </div>
                      </div>
                      <div className="text-sm font-medium" style={{ color: '#3E2723' }}>
                        R$ {(reserva.valor / 100).toFixed(2).replace('.', ',')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => setModalExcluir(true)}
            className="w-full py-3 rounded-full mt-6 border-2"
            style={{ borderColor: '#D32F2F', color: '#D32F2F' }}
          >
            Apagar cliente
          </button>
        </div>
      </div>

      {modalEditar && (
        <EditarClienteModal
          cliente={cliente}
          onClose={() => setModalEditar(false)}
          onSave={(clienteAtualizado) => {
            atualizarCliente(clienteAtualizado.id, clienteAtualizado);
            setModalEditar(false);
          }}
        />
      )}

      <AnimatePresence>
        {modalExcluir && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40"
              onClick={() => setModalExcluir(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white rounded-3xl p-8 shadow-2xl w-[90vw] max-w-sm"
            >
              <h3 className="text-lg mb-6 text-center" style={{ color: '#5D4037' }}>
                Tem certeza que deseja apagar cliente?
              </h3>

              <div className="flex gap-4">
                <button
                  onClick={() => setModalExcluir(false)}
                  className="flex-1 py-3 rounded-full border-2"
                  style={{ borderColor: '#5D4037', color: '#5D4037' }}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleExcluirCliente}
                  className="flex-1 py-3 rounded-full text-white"
                  style={{ backgroundColor: '#5D4037' }}
                >
                  Excluir
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <CalendarioAdminModal
        isOpen={calendarioAberto}
        onClose={() => setCalendarioAberto(false)}
        onSelectDate={handleSelecionarData}
        selectedDate={dataSelecionada}
      />

      {modalAdicionarTurno && (
        <AdicionarTurnoModal
          onClose={() => setModalAdicionarTurno(false)}
          onSave={handleAdicionarTurno}
        />
      )}

      {erroTurno && <ErroTurnoModal onClose={() => setErroTurno(false)} mensagem={erroMensagem} />}

      {/* Modal Adicionar Crédito */}
      {modalAdicionarCredito && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl"
          >
            <h2 className="text-lg mb-4" style={{ color: '#5D4037' }}>
              Adicionar Crédito
            </h2>

            <div className="mb-6">
              <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                Valor
              </label>
              <input
                type="text"
                placeholder="R$ 0,00"
                value={`R$ ${valorCredito}`}
                onChange={(e) => setValorCredito(formatValor(e.target.value))}
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                autoFocus
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setModalAdicionarCredito(false);
                  setValorCredito('');
                }}
                className="flex-1 py-3 rounded-full border-2"
                style={{ borderColor: '#5D4037', color: '#5D4037' }}
              >
                Cancelar
              </button>
              <button
                onClick={handleAdicionarCredito}
                className="flex-1 py-3 rounded-full text-white"
                style={{ backgroundColor: '#5D4037' }}
              >
                Adicionar
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Modal Excluir Crédito */}
      {modalExcluirCredito && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-xl"
          >
            <h2 className="text-lg mb-4" style={{ color: '#5D4037' }}>
              Excluir Crédito
            </h2>

            <p className="text-sm mb-4" style={{ color: '#8D6E63' }}>
              Crédito disponível: R$ {(creditos / 100).toFixed(2).replace('.', ',')}
            </p>

            <div className="mb-6">
              <label className="block text-sm mb-2" style={{ color: '#5D4037' }}>
                Valor a excluir
              </label>
              <input
                type="text"
                placeholder="R$ 0,00"
                value={`R$ ${valorExcluir}`}
                onChange={(e) => setValorExcluir(formatValor(e.target.value))}
                className="w-full px-4 py-3 rounded-2xl border text-sm"
                style={{ borderColor: '#E0E0E0', color: '#3E2723' }}
                autoFocus
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setModalExcluirCredito(false);
                  setValorExcluir('');
                }}
                className="flex-1 py-3 rounded-full border-2"
                style={{ borderColor: '#5D4037', color: '#5D4037' }}
              >
                Cancelar
              </button>
              <button
                onClick={handleExcluirCredito}
                className="flex-1 py-3 rounded-full text-white"
                style={{ backgroundColor: '#D32F2F' }}
              >
                Excluir
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
}