import { createBrowserRouter } from 'react-router';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Cadastro } from './pages/Cadastro';
import { Conta } from './pages/Conta';
import { MinhasReservas } from './pages/MinhasReservas';
import { ConfirmarReserva } from './pages/ConfirmarReserva';
import { Pagamento } from './pages/Pagamento';
import { Creditos } from './pages/Creditos';
import { AdminReservas } from './pages/admin/AdminReservas';
import { AdminClientes } from './pages/admin/AdminClientes';
import { AdminConfigurar } from './pages/admin/AdminConfigurar';
import { DetalhesCliente } from './pages/admin/DetalhesCliente';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Home,
  },
  {
    path: '/login',
    Component: Login,
  },
  {
    path: '/cadastro',
    Component: Cadastro,
  },
  {
    path: '/conta',
    Component: Conta,
  },
  {
    path: '/minhas-reservas',
    Component: MinhasReservas,
  },
  {
    path: '/confirmar-reserva',
    Component: ConfirmarReserva,
  },
  {
    path: '/pagamento',
    Component: Pagamento,
  },
  {
    path: '/creditos',
    Component: Creditos,
  },
  {
    path: '/admin/reservas',
    Component: AdminReservas,
  },
  {
    path: '/admin/clientes',
    Component: AdminClientes,
  },
  {
    path: '/admin/configurar',
    Component: AdminConfigurar,
  },
  {
    path: '/admin/clientes/detalhes',
    Component: DetalhesCliente,
  },
]);