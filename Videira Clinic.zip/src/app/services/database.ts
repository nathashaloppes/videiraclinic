// Serviço de banco de dados simulado com localStorage
// Pode ser facilmente substituído por Supabase no futuro

export interface DBUser {
  id: string;
  nomeCompleto: string;
  email: string;
  senha: string;
  telefone: string;
  registroCRO: string;
  areaAtuacao: string;
  dataNascimento?: string;
  endereco?: string;
  fotoPerfil?: string;
  isAdmin?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DBReserva {
  id: string;
  userId: string;
  data: string; // YYYY-MM-DD
  inicio: string; // HH:mm
  fim: string; // HH:mm
  periodo: string;
  valor: number;
  status: 'confirmada' | 'cancelada';
  creditoUtilizado?: number;
  createdAt: string;
  updatedAt: string;
}

export interface DBCredito {
  userId: string;
  saldo: number;
  updatedAt: string;
}

export interface DBTransacao {
  id: string;
  userId: string;
  reservaId?: string;
  tipo: 'credito' | 'debito';
  valor: number;
  descricao: string;
  createdAt: string;
}

export interface DBTurno {
  id: string;
  data: string; // YYYY-MM-DD
  periodo: string;
  inicio: string;
  fim: string;
  valor: number;
  ativo: boolean;
  createdAt: string;
  updatedAt: string;
}

class Database {
  private getItem<T>(key: string): T[] {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  }

  private setItem<T>(key: string, data: T[]): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  // ==================== USUÁRIOS ====================

  getAllUsers(): DBUser[] {
    return this.getItem<DBUser>('vdc_users');
  }

  getUserById(id: string): DBUser | null {
    const users = this.getAllUsers();
    return users.find(u => u.id === id) || null;
  }

  getUserByEmail(email: string): DBUser | null {
    const users = this.getAllUsers();
    return users.find(u => u.email === email) || null;
  }

  createUser(user: Omit<DBUser, 'id' | 'createdAt' | 'updatedAt'>): DBUser {
    const users = this.getAllUsers();
    const newUser: DBUser = {
      ...user,
      id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    users.push(newUser);
    this.setItem('vdc_users', users);
    return newUser;
  }

  updateUser(id: string, updates: Partial<DBUser>): DBUser | null {
    const users = this.getAllUsers();
    const index = users.findIndex(u => u.id === id);
    if (index === -1) return null;

    users[index] = {
      ...users[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.setItem('vdc_users', users);
    return users[index];
  }

  deleteUser(id: string): boolean {
    const users = this.getAllUsers();
    const filtered = users.filter(u => u.id !== id);
    if (filtered.length === users.length) return false;
    this.setItem('vdc_users', filtered);
    return true;
  }

  // ==================== RESERVAS ====================

  getAllReservas(): DBReserva[] {
    return this.getItem<DBReserva>('vdc_reservas');
  }

  getReservaById(id: string): DBReserva | null {
    const reservas = this.getAllReservas();
    return reservas.find(r => r.id === id) || null;
  }

  getReservasByUserId(userId: string): DBReserva[] {
    const reservas = this.getAllReservas();
    return reservas.filter(r => r.userId === userId && r.status === 'confirmada');
  }

  getReservasByData(data: string): DBReserva[] {
    const reservas = this.getAllReservas();
    return reservas.filter(r => r.data === data && r.status === 'confirmada');
  }

  createReserva(reserva: Omit<DBReserva, 'id' | 'createdAt' | 'updatedAt'>): DBReserva {
    const reservas = this.getAllReservas();
    const newReserva: DBReserva = {
      ...reserva,
      id: `reserva_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reservas.push(newReserva);
    this.setItem('vdc_reservas', reservas);
    return newReserva;
  }

  updateReserva(id: string, updates: Partial<DBReserva>): DBReserva | null {
    const reservas = this.getAllReservas();
    const index = reservas.findIndex(r => r.id === id);
    if (index === -1) return null;

    reservas[index] = {
      ...reservas[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.setItem('vdc_reservas', reservas);
    return reservas[index];
  }

  deleteReserva(id: string): boolean {
    const reservas = this.getAllReservas();
    const filtered = reservas.filter(r => r.id !== id);
    if (filtered.length === reservas.length) return false;
    this.setItem('vdc_reservas', filtered);
    return true;
  }

  // ==================== CRÉDITOS ====================

  getCredito(userId: string): number {
    const creditos = this.getItem<DBCredito>('vdc_creditos');
    const credito = creditos.find(c => c.userId === userId);
    return credito?.saldo || 0;
  }

  setCredito(userId: string, saldo: number): void {
    const creditos = this.getItem<DBCredito>('vdc_creditos');
    const index = creditos.findIndex(c => c.userId === userId);

    if (index === -1) {
      creditos.push({
        userId,
        saldo,
        updatedAt: new Date().toISOString(),
      });
    } else {
      creditos[index] = {
        ...creditos[index],
        saldo,
        updatedAt: new Date().toISOString(),
      };
    }
    this.setItem('vdc_creditos', creditos);
  }

  adicionarCredito(userId: string, valor: number, descricao: string, reservaId?: string): void {
    const saldoAtual = this.getCredito(userId);
    this.setCredito(userId, saldoAtual + valor);
    this.createTransacao({
      userId,
      reservaId,
      tipo: 'credito',
      valor,
      descricao,
    });
  }

  debitarCredito(userId: string, valor: number, descricao: string, reservaId?: string): boolean {
    const saldoAtual = this.getCredito(userId);
    if (saldoAtual < valor) return false;

    this.setCredito(userId, saldoAtual - valor);
    this.createTransacao({
      userId,
      reservaId,
      tipo: 'debito',
      valor,
      descricao,
    });
    return true;
  }

  // ==================== TRANSAÇÕES ====================

  getAllTransacoes(): DBTransacao[] {
    return this.getItem<DBTransacao>('vdc_transacoes');
  }

  getTransacoesByUserId(userId: string): DBTransacao[] {
    const transacoes = this.getAllTransacoes();
    return transacoes.filter(t => t.userId === userId);
  }

  createTransacao(transacao: Omit<DBTransacao, 'id' | 'createdAt'>): DBTransacao {
    const transacoes = this.getAllTransacoes();
    const newTransacao: DBTransacao = {
      ...transacao,
      id: `transacao_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
    };
    transacoes.push(newTransacao);
    this.setItem('vdc_transacoes', transacoes);
    return newTransacao;
  }

  // ==================== TURNOS ====================

  getAllTurnos(): DBTurno[] {
    return this.getItem<DBTurno>('vdc_turnos');
  }

  getTurnosByData(data: string): DBTurno[] {
    const turnos = this.getAllTurnos();
    return turnos.filter(t => t.data === data);
  }

  createTurno(turno: Omit<DBTurno, 'id' | 'createdAt' | 'updatedAt'>): DBTurno {
    const turnos = this.getAllTurnos();
    const newTurno: DBTurno = {
      ...turno,
      id: `turno_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    turnos.push(newTurno);
    this.setItem('vdc_turnos', turnos);
    return newTurno;
  }

  updateTurno(id: string, updates: Partial<DBTurno>): DBTurno | null {
    const turnos = this.getAllTurnos();
    const index = turnos.findIndex(t => t.id === id);
    if (index === -1) return null;

    turnos[index] = {
      ...turnos[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.setItem('vdc_turnos', turnos);
    return turnos[index];
  }

  deleteTurno(id: string): boolean {
    const turnos = this.getAllTurnos();
    const filtered = turnos.filter(t => t.id !== id);
    if (filtered.length === turnos.length) return false;
    this.setItem('vdc_turnos', filtered);
    return true;
  }

  // Marcar turnos como reservados
  marcarTurnosComoReservados(data: string, inicio: string, fim: string): void {
    const turnos = this.getAllTurnos();
    let updated = false;

    turnos.forEach((turno) => {
      if (turno.data === data && turno.ativo) {
        // Verificar se o turno está dentro do intervalo da reserva
        const turnoInicio = turno.inicio;
        const turnoFim = turno.fim;

        // Se houver sobreposição de horários
        if (
          (turnoInicio >= inicio && turnoInicio < fim) ||
          (turnoFim > inicio && turnoFim <= fim) ||
          (turnoInicio <= inicio && turnoFim >= fim)
        ) {
          turno.ativo = false;
          turno.updatedAt = new Date().toISOString();
          updated = true;
        }
      }
    });

    if (updated) {
      this.setItem('vdc_turnos', turnos);
      window.dispatchEvent(new Event('turnosAtualizados'));
    }
  }

  // Liberar turnos quando reserva é cancelada ou alterada
  liberarTurnos(data: string, inicio: string, fim: string, reservaIdExcluir?: string): void {
    const turnos = this.getAllTurnos();
    const reservas = this.getReservasByData(data)
      .filter(r => r.status === 'confirmada')
      .filter(r => !reservaIdExcluir || r.id !== reservaIdExcluir); // Excluir reserva sendo alterada
    let updated = false;

    const horarioDentroDeOutro = (inicio1: string, fim1: string, inicio2: string, fim2: string): boolean => {
      const [h1i, m1i] = inicio1.split(':').map(Number);
      const [h1f, m1f] = fim1.split(':').map(Number);
      const [h2i, m2i] = inicio2.split(':').map(Number);
      const [h2f, m2f] = fim2.split(':').map(Number);

      const min1i = h1i * 60 + m1i;
      const min1f = h1f * 60 + m1f;
      const min2i = h2i * 60 + m2i;
      const min2f = h2f * 60 + m2f;

      return (min1i < min2f && min1f > min2i);
    };

    turnos.forEach((turno) => {
      if (turno.data === data && !turno.ativo) {
        // Verificar se o turno estava dentro do intervalo da reserva que foi cancelada
        if (horarioDentroDeOutro(turno.inicio, turno.fim, inicio, fim)) {
          // Verificar se não há outras reservas que colidem com este turno
          const temOutraReserva = reservas.some(r =>
            horarioDentroDeOutro(turno.inicio, turno.fim, r.inicio, r.fim)
          );

          // Verificar se não há outros turnos ativos que colidem com este turno
          const temOutroTurnoAtivo = turnos.some(outroTurno =>
            outroTurno.id !== turno.id &&
            outroTurno.data === data &&
            outroTurno.ativo &&
            horarioDentroDeOutro(turno.inicio, turno.fim, outroTurno.inicio, outroTurno.fim)
          );

          // Só reativar se não houver colisões
          if (!temOutraReserva && !temOutroTurnoAtivo) {
            turno.ativo = true;
            turno.updatedAt = new Date().toISOString();
            updated = true;
          }
        }
      }
    });

    if (updated) {
      this.setItem('vdc_turnos', turnos);
      window.dispatchEvent(new Event('turnosAtualizados'));
    }
  }

  // ==================== INICIALIZAÇÃO ====================

  initialize(): void {
    // Criar usuário admin padrão
    const users = this.getAllUsers();

    if (users.length === 0) {
      // Admin 1
      this.createUser({
        nomeCompleto: 'Administrador Videira Clinic',
        email: 'nathashaloppes@outlook.com',
        senha: '@Leleco06',
        telefone: '+55 85 98765-1914',
        registroCRO: 'CRO-CE 00000',
        areaAtuacao: 'Administração',
        isAdmin: true,
      });

      // Admin 2
      this.createUser({
        nomeCompleto: 'Videira Clinic',
        email: 'videiraclinic@gmail.com',
        senha: 'Ci061120@',
        telefone: '+55 85 98765-1914',
        registroCRO: 'CRO-CE 00001',
        areaAtuacao: 'Administração',
        isAdmin: true,
      });

      // Usuário de teste
      this.createUser({
        nomeCompleto: 'Nathasha Leite Lopes',
        email: 'nathasha@gmail.com',
        senha: 'leleco06',
        telefone: '+55 85 98765-1914',
        registroCRO: 'CRO-CE 12345',
        areaAtuacao: 'Ortodontia',
        dataNascimento: '15/05/2001',
        endereco: 'Rua das Carnubas, 777, Bloco B apto 407, Parauá, Fortaleza - CE, 60118-785',
      });
    } else {
      // Garantir que o usuário de teste existe (mesmo que o banco já tenha sido inicializado)
      const nathashaExists = this.getUserByEmail('nathasha@gmail.com');
      if (!nathashaExists) {
        this.createUser({
          nomeCompleto: 'Nathasha Leite Lopes',
          email: 'nathasha@gmail.com',
          senha: 'leleco06',
          telefone: '+55 85 98765-1914',
          registroCRO: 'CRO-CE 12345',
          areaAtuacao: 'Ortodontia',
          dataNascimento: '15/05/2001',
          endereco: 'Rua das Carnubas, 777, Bloco B apto 407, Parauá, Fortaleza - CE, 60118-785',
        });
      }
    }
  }
}

export const db = new Database();
